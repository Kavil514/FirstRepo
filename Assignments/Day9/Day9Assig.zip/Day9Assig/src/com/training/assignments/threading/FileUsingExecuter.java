package com.training.assignments.threading;

import java.io.File;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.TimeUnit;

public class FileUsingExecuter {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		File filein = new File("source.txt");
		File fileout = new File("target.txt");
		CopyDataThread copy = new CopyDataThread(filein, fileout);
		ExecutorService e = Executors.newCachedThreadPool();
		e.execute(copy);
		try {
			e.awaitTermination(20, TimeUnit.SECONDS);
			e.shutdownNow();
		} catch (InterruptedException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}

	}
}
