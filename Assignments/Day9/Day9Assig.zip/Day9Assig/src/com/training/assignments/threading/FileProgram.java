package com.training.assignments.threading;

import java.io.File;
import java.io.IOException;

public class FileProgram {

	public static void main(String[] args) throws IOException, InterruptedException {
		File filein = new File("source.txt");
		File fileout = new File("target.txt");
		CopyDataThread thread = new CopyDataThread(filein,fileout);
		thread.start();
	}

}
