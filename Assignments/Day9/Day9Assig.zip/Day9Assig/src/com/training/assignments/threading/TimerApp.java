package com.training.assignments.threading;

import java.util.Scanner;

public class TimerApp {

	public static void main(String[] args) {
		new Thread(new Runnable() {
			public void run() {
				Scanner sc = new Scanner(System.in);
				System.out.println("Set the seconds for timer");
				int seconds = sc.nextInt();
				for (int timer = 0; timer <= seconds; timer+=10) {
					int hrs = timer / (60 * 60);
					int minutes = timer / 60;
					int secs = timer % 60;
					if (minutes == 60) {
						minutes %= 60;
						hrs++;
					}

					if (hrs < 10) {
						if (minutes < 10 && secs < 10) {
							System.out.println("Time Elapsed:: " + "0" + hrs + " : 0" + minutes + " : 0" + secs);
						} else if (minutes < 10 && secs >= 10) {
							System.out.println("Time Elapsed:: " + "0" + hrs + " : 0" + minutes + " : " + secs);
						} else if (minutes >= 10 && secs < 10) {
							System.out.println("Time Elapsed:: " + "0" + hrs + " : " + minutes + " : 0" + secs);
						} else {
							System.out.println("Time Elapsed:: " + "0" + hrs + " : " + minutes + " : " + secs);
						}
					} else {
						if (minutes < 10 && secs < 10) {
							System.out.println("Time Elapsed:: " + hrs + " : 0" + minutes + " : 0" + secs);
						} else if (minutes < 10 && secs >= 10) {
							System.out.println("Time Elapsed:: " + hrs + " : 0" + minutes + " : " + secs);
						} else if (minutes >= 10 && secs < 10) {
							System.out.println("Time Elapsed:: " + hrs + " : " + minutes + " : 0" + secs);
						} else {
							System.out.println(hrs + " : " + minutes + ":" + secs);
						}
					}

					try {
						Thread.sleep(10000);
					} catch (InterruptedException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
				}

			}
		}).start();

	}
}
