package com.training.assignments.threading;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;

public class CopyDataThread extends Thread {
	private File filein;
	private File fileout;
	private FileInputStream fin;
	private FileOutputStream fout;

	private int i = 0;
	private int j = 0;

	public CopyDataThread(File filein, File fileout) {
		super("Copying Data");
		this.filein = filein;
		this.fileout = fileout;

	}

	public void copy_data() throws IOException {

		fin = new FileInputStream(filein);
		fout = new FileOutputStream(fileout);

		while ((i = fin.read()) != -1) {
			System.out.println((char) i);
			fout.write(i);
			j ++;
			if (j % 10 == 0) {
				System.out.println("10 Characters copied");
				try {
					Thread.sleep(5000);
				} catch (InterruptedException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
			

		}

	}

	@Override
	public void run() {
		try {
			this.copy_data();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

}
