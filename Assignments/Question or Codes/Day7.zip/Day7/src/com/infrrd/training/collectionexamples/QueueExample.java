package com.infrrd.training.collectionexamples;

import java.util.*;
public class QueueExample {

	public static void main(String[] args) {
		
		Queue<String> queue=new PriorityQueue<String>();
		System.out.println(queue.poll());
		System.out.println(queue.peek());
		queue.add("Watch");
		queue.add("Ring");
		queue.add("Alexa");
		queue.add("Mi4");
		
		System.out.println(queue);
		queue.poll();//--to remove the head of the queue
		System.out.println(queue);
		System.out.println(queue.peek());//to retirve the head of the element
		System.out.println(queue);

		
		Deque<String> dQueue=new ArrayDeque<String>();
		dQueue.add("Watch");
		dQueue.add("Ring");
		dQueue.add("Alexa");
		dQueue.add("Mi4");
		
		System.out.println(dQueue);
		
		dQueue.remove();
		System.out.println(dQueue);
		
		dQueue.removeLast();
		System.out.println(dQueue);
		
		dQueue.addFirst("Vivo11");
		System.out.println(dQueue);
	}

}
