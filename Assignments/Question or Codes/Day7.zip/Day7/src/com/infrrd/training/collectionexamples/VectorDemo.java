package com.infrrd.training.collectionexamples;

import java.time.LocalDate;
import java.util.Date;
import java.util.Hashtable;
import java.util.Vector;

import com.infrrd.training.pojos.User;

public class VectorDemo {

	public static void main(String[] args) {
		
		String st=new String("Shwetha");
		String st2=new String("Shwetha");
		String st3=new String("hSwetah");
		
		System.out.println(st3.hashCode()+" for st3");
		
		if(st.equals(st2)) {
			System.out.println("true");
		}
		
		System.out.println(st.hashCode()+" for st2");
		System.out.println(st2.hashCode());
		
		User user=new User("Shwetha","1234","admin",LocalDate.now(),1234567890);
		System.out.println(user.hashCode()+" User Object 1");
		System.out.println(user.hashCode()%16);
		User user1=new User("Shwetha","1234","admin",LocalDate.now(),1234567890);
		System.out.println(user1.hashCode()+" User Object 2");
		System.out.println(user1.hashCode()%16);
		
		if(user.equals(user1)) {
			System.out.println("Objects are equals");
		}else {
			System.out.println("Objects are not equals");
		}
		
		//java 1 and 1.1
		Vector v1=new Vector(1);
		System.out.println(v1.size());
		v1.addElement("String");
		v1.addElement(1234);
		v1.addElement(23456.89);
		v1.addElement('c');
		v1.addElement(new StringBuilder("StringB"));
		v1.addElement(new Date());
		v1.addElement("Mobile");
		v1.addElement(23456);
		v1.addElement(23456.89);
		v1.addElement('c');
		
		System.out.println(v1+" "+v1.size());
		
		v1.addElement("String");
		v1.addElement(1234);
		v1.addElement(23456.89);
		v1.addElement('c');
		System.out.println(v1+" "+v1.size());
		System.out.println(v1.get(4));
		
		Hashtable ht=new Hashtable();
		ht.put("St", "String00");
		ht.put("12", "Shwetha");
		ht.put(1,65767);
		System.out.println(ht);

	}

}
