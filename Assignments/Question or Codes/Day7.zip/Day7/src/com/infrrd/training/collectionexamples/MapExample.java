package com.infrrd.training.collectionexamples;

import java.util.*;
import java.util.Map.Entry;

import com.infrrd.training.pojos.Answer;
import com.infrrd.training.pojos.Question;
public class MapExample {

	public static void main(String[] args) {
		Map<Integer,String> map1=new TreeMap<>();
		map1.put(12,"Oppf11pr0");
		map1.put(2,"Oppf12pr0");
		map1.put(78,"Oppf13pr0");
		map1.put(67,"Oppf11pr0");
		map1.put(78,"oopf45");
		System.out.println(map1);
		
		Set<Answer> answer1=new TreeSet<>();
		answer1.add(new Answer('A', "List"));
		answer1.add(new Answer('B', "Set"));
		answer1.add(new Answer('C', "Queue"));
		answer1.add(new Answer('D', "Map"));
		answer1.add(new Answer('A', "List"));
		
		
		Set<Answer> answer2=new TreeSet<>();
		answer2.add(new Answer('A', "Yes"));
		answer2.add(new Answer('B', "No"));
		answer2.add(new Answer('C', "SomeWhat"));
		answer2.add(new Answer('D', "Notatall"));
		
		
		Map<Question, Set<Answer>> mcqs=new Hashtable<>();
		mcqs.put(new Question(1, "Which Doesnot allow duplicate values?", "collection API Code"), answer1);
		mcqs.put(new Question(2, "Is collection boring?", "collection API Code"), answer2);
		mcqs.put(new Question(2, "Is collection boring?", "collection API Code"), answer1);
		
		//System.out.println(mcqs.get(new Question(1, "Which Doesnot allow duplicate values?", "collection API Code")));
		
		for(Entry<Question, Set<Answer>> m1:mcqs.entrySet()) {
			System.out.println(m1.getKey());
		   Set<Answer> answers=m1.getValue();
		   answers.forEach(a->System.out.println(a));
		}
		
		//Map<List<String>, Set<Answer>>
		//Map<Map<Integer,String>, Map<String,Integer>>
	}

}
