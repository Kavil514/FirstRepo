package com.infrrd.training.collectionexamples;

import java.util.*;

public class SetDemo {

	public static void main(String[] args) {
		Set s1=new TreeSet();
		//List s1=new ArrayList();
		s1.add("Str");
		s1.add("Str2");
		s1.add("Str3");
		s1.add("Str4");
		s1.add("Str5");
		s1.add("Str");
		s1.add("Str6");
		s1.add("Abc");
		s1.add("inf");
		
		System.out.println(s1);

	}

}
