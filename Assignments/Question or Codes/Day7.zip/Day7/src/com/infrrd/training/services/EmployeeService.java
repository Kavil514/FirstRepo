package com.infrrd.training.services;

import java.util.List;

import com.infrrd.training.exceptions.BusinessException;
import com.infrrd.training.pojos.Employee;

public interface EmployeeService {

	public List<Employee> getAll()throws BusinessException;
	public Employee getEmployee(int index);
	public void addEmployee(Employee e);
	public void deleteEmployee(int eid);
	public void deleteEmployeeOnSalary(double sal);
}
