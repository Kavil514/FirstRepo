package com.infrrd.training.collectionexamples;


interface A{
	public void display();
}
class Parent{
	
	public void display() {
		System.out.println("parent");
	}
}
class Child extends Parent implements A{
	
	
}

public class Doubt {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
