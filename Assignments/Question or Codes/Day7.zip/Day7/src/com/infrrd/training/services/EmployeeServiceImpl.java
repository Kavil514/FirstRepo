package com.infrrd.training.services;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import com.infrrd.training.exceptions.BusinessException;
import com.infrrd.training.pojos.Employee;

public class EmployeeServiceImpl implements EmployeeService {
	
	List<Employee> employees;
	public EmployeeServiceImpl() {
		employees=new ArrayList<>();
	}

	@Override
	public List<Employee> getAll()throws BusinessException {
		if(employees.isEmpty()) {
			throw new BusinessException("List is Empty");
		}
		return employees;
	}

	@Override
	public Employee getEmployee(int index) {
		return employees.get(index);
	}

	@Override
	public void addEmployee(Employee e) {
		employees.add(e);
	}

	@Override
	public void deleteEmployee(int id) {	
		//Employee e=employees.get(index)
		//based on index
		//employees.remove(index);
		//based on id
//		for(Employee e:employees) {
//			if(e.getEid()== id) {
//				employees.remove(e);
//			}
//		}
		
//		Iterator<Employee> itr=employees.iterator();
//		while(itr.hasNext()) {
//			Employee e=itr.next();
//			if(e.getEid() == id) {
//				itr.remove();
//			}
//		}
		//java 8
		
		employees.removeIf(e -> e.getEid()==id);
		
	}

	@Override
	public void deleteEmployeeOnSalary(double  sal) {
//		Iterator<Employee> itr=employees.iterator();
//		while(itr.hasNext()) {
//			Employee e=itr.next();
//			if(e.getSalary() == sal) {
//				itr.remove();
//			}
//		}
		employees.removeIf(e -> e.getSalary()== sal);
	}

}
