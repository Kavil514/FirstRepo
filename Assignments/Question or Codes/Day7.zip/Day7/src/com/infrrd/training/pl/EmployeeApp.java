package com.infrrd.training.pl;

import java.util.Collections;
import java.util.List;
import java.util.Scanner;

import com.infrrd.training.exceptions.BusinessException;
import com.infrrd.training.pojos.Employee;
import com.infrrd.training.services.EmployeeService;
import com.infrrd.training.services.EmployeeServiceImpl;

public class EmployeeApp {

	public static void main(String[] args) {
		System.out.println("Welcome to Employee App");
		Scanner sc=new Scanner(System.in);
		EmployeeService eService=new EmployeeServiceImpl();
		List<Employee> employees;
		do {
		System.out.println("1. AddEmployee \n 2. Delete Employee\n 3. GetEmployee\n 4. GetAll Employees "
				+ "\n 5. Sort Employee Based on Names \n 6. Sort Based on Salary \n 7. exit");
		switch(sc.nextInt()) {
		case 1:Employee emp=new Employee(sc.nextInt(), sc.next(), sc.nextDouble());
			eService.addEmployee(emp);
			System.out.println("Employee added");
			break;
		case 2:System.out.println("Enter the id which you want to delete");
				eService.deleteEmployee(sc.nextInt());
				System.out.println("EMployee Deleted");
			break;
		case 3:System.out.println("Enter the index ");
		Employee e=eService.getEmployee(sc.nextInt());
		System.out.println(e);
			break;
		case 4:
			try {
				employees = eService.getAll();
				Collections.sort(employees);
				employees.forEach(es -> System.out.println(es));
			} catch (BusinessException e2) {
				e2.printStackTrace();
			}
	
			break;
		case 5: 
		try {
			employees = eService.getAll();
			Collections.sort(employees,(e1,e2)-> e1.getEname().compareTo(e2.getEname()));
			for(Employee e1:employees) {
				System.out.println(e1);
			}
		} catch (BusinessException e2) {
			e2.printStackTrace();
		}
			break;
		case 6:	try {
			employees = eService.getAll();
			Collections.sort(employees,(e1,e2)-> (int)(e1.getSalary()-e2.getSalary()));
			for(Employee e1:employees) {
				System.out.println(e1);
			}
		} catch (BusinessException e2) {
			e2.printStackTrace();
		}
			break;
		case 7:System.out.println("Thank You");
			sc.close();
			System.exit(0);
			break;
		default: System.out.println("Invalid");
		}
		}while(true);
	}

}
