package com.infrrd.training.collectionexamples;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashSet;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;
import java.util.ListIterator;
import java.util.Set;
import java.util.TreeSet;

import com.infrrd.training.pojos.Employee;
import com.infrrd.training.pojos.User;

public class Listexample {

	public static void main(String[] args) {
		
		List<Integer> numbers=new ArrayList<>();
		numbers.add(12);
		numbers.add(67);
		
		//List<Integer> nums=Arrays.asList(10,89,87,34,67);
		List<Integer> nums=new LinkedList<>();
		nums.add(33);
		nums.add(0,678);
		nums.add(33);
		nums.add(32);
		nums.add(78);
		nums.add(3);
		
		//System.out.println(numbers);
		//System.out.println(nums);
		
		//nums.addAll(numbers);
		
		System.out.println(nums);

		//nums.removeAll(numbers);
		//nums.retainAll(numbers);
		
		//nums.clear();
		System.out.println(nums);
		
		System.out.println(Collections.binarySearch(nums, 33));
		Collections.shuffle(nums);
		System.out.println(nums);
		
		
		
		
		
		
		
		
		
		
		
//		
//		
//	  User u1=new User("Somil", "som123", "admin", LocalDate.of(2010, 03, 03), 456789);
//	  User u2=new User("Sunil", "sun123", "user", LocalDate.of(2010, 03, 03), 456789);
//	  User u3=new User("Komal", "kom123", "admin", LocalDate.of(2010, 03, 03), 456789);
//	  User u4=new User("Komal", "kom123", "admin", LocalDate.of(2010, 03, 03), 456789);
//	  
//	  Employee e1=new Employee(1233, "Adithya", 6757890);
//	  Employee e2=new Employee(1234, "Shiv", 6787890);
//	  Employee e3=new Employee(1235, "Abinav", 6757890);
//	  //java 5
//	  List<User> listOfObjectsList=new ArrayList<>();
//	  //Set<User> listOfObjectsList=new TreeSet<>();
////	  listOfObjectsList.add(e3);
////	  listOfObjectsList.add(e2);
////	  listOfObjectsList.add(0,e1);
//	  listOfObjectsList.add(u1);
//	  listOfObjectsList.add(u2);
//	  listOfObjectsList.add(u3);
//	  listOfObjectsList.add(u4);
//	  
//	  for(User u:listOfObjectsList) {
//	  System.out.println(u);
//	  }
//	  
//	  System.out.println("Iterator--single direction");
//	  Iterator<User> itr=listOfObjectsList.iterator();
//	  while(itr.hasNext()) {
//		  System.out.println(itr.next());
//	  }
//	  
//	  System.out.println("List Iterator--By Direction");
//	  ListIterator<User> litr=listOfObjectsList.listIterator(2);
//	  while(litr.hasPrevious()) {
//		  System.out.println(litr.previous());
//	  }
//	  
//	  System.out.println("Java 8");
//	  //java 8
//	  listOfObjectsList.forEach(u->System.out.println(u));
//	  System.out.println("-======================");
//	  
//	  
//	  
//	  
//	  
//	  System.out.println("After Sorting");
//	  Collections.sort(listOfObjectsList);
//	  
//	  for(User u:listOfObjectsList) {
//		  System.out.println(u);
//		  }
//	  
//	  System.out.println("Sort the users based on their role");
//	  
//	  Collections.sort(listOfObjectsList, (User u9, User u6)-> u9.getRole().compareTo(u6.getRole()));
//	  for(User u:listOfObjectsList) {
//		  System.out.println(u);
//		  }
//	 System.out.println("Sort based on contact number");
//	 Collections.sort(listOfObjectsList,(u10,u11)->(int)(u10.getContactNumber()-u11.getContactNumber()));
//	   
//	 for(User u:listOfObjectsList) {
//		  System.out.println(u);
//		  }
//	  
	  
	  
//	  List words=new ArrayList();
//	  words.add("Hell o");
//	  words.add("world!");
//	  
//	  String s=(String) words.get(0)+words.get(1);
//	  assert s.equals("Hello world!");
//	  
//	  List<String> words1=new ArrayList();
//	  words1.add("Hell o");
//	  words1.add("world!");
//	  
//	  String s1=words1.get(0)+words1.get(1);
//	  assert s1.equals("Hello world!");
	  
	  
	  
	}

}
