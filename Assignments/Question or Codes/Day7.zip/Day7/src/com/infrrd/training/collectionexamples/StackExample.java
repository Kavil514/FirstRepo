package com.infrrd.training.collectionexamples;

import java.util.Stack;

public class StackExample {

	public static void main(String[] args) {
	Stack<String> stack=new Stack<String>();
	stack.add("Mi11");
	stack.add("OppF11");
	stack.add("Oppf19");
	System.out.println(stack);
	
	stack.remove(2);
	System.out.println(stack);
	}

}
