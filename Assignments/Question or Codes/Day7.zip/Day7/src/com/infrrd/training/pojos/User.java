package com.infrrd.training.pojos;

import java.time.LocalDate;

public class User implements Comparable<User> {

	private String uname;
	private String password;
	private String role;
	private LocalDate dob;
	private long contactNumber;
	
	
	
	
//	public boolean equals(User user) {
//		if(user!= null) {
//			if(!user.uname.equals(this.getUname())) {
//				return false;
//			}else {
//				if(!user.password.equals(this.getPassword())) {
//					return false;
//				}else {
//					if(!user.role.equals(this.getRole())) {
//						return false;
//					}else {
//						if(!user.dob.equals(this.getDob())) {
//							if(user.contactNumber  != this.contactNumber) {
//								return false;
//							}
//						}
//					}
//				}
//			}
//		}else {
//			return true;
//		}
//		
//		return true;
//	}
	
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + (int) (contactNumber ^ (contactNumber >>> 32));
		result = prime * result + ((dob == null) ? 0 : dob.hashCode());
		result = prime * result + ((password == null) ? 0 : password.hashCode());
		result = prime * result + ((role == null) ? 0 : role.hashCode());
		result = prime * result + ((uname == null) ? 0 : uname.hashCode());
		return result;
	}
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		User other = (User) obj;
		if (contactNumber != other.contactNumber)
			return false;
		if (dob == null) {
			if (other.dob != null)
				return false;
		} else if (!dob.equals(other.dob))
			return false;
		if (password == null) {
			if (other.password != null)
				return false;
		} else if (!password.equals(other.password))
			return false;
		if (role == null) {
			if (other.role != null)
				return false;
		} else if (!role.equals(other.role))
			return false;
		if (uname == null) {
			if (other.uname != null)
				return false;
		} else if (!uname.equals(other.uname))
			return false;
		return true;
	}
	public User(String uname, String password, String role, LocalDate dob, long contactNumber) {
		//super();
		this.uname = uname;
		this.password = password;
		this.role = role;
		this.dob = dob;
		this.contactNumber = contactNumber;
	}
	public User() {
		// TODO Auto-generated constructor stub
	}
	public String getUname() {
		return uname;
	}
	public void setUname(String uname) {
		this.uname = uname;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public String getRole() {
		return role;
	}
	public void setRole(String role) {
		this.role = role;
	}
	public LocalDate getDob() {
		return dob;
	}
	public void setDob(LocalDate dob) {
		this.dob = dob;
	}
	public long getContactNumber() {
		return contactNumber;
	}
	public void setContactNumber(long contactNumber) {
		this.contactNumber = contactNumber;
	}
	@Override
	public String toString() {
		return "User [uname=" + uname + ", password=" + password + ", role=" + role + ", dob=" + dob
				+ ", contactNumber=" + contactNumber + "]";
	}
	@Override
	public int compareTo(User o) {
	
		return this.uname.compareTo(o.getUname());
	}
	
	
}
