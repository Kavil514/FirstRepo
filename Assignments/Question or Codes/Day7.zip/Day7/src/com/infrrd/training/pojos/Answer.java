package com.infrrd.training.pojos;

public class Answer implements Comparable<Answer> {
	
	private char option;
	private String answer;
	public Answer(char option, String answer) {
		this.option = option;
		this.answer = answer;
	}
	public char getOption() {
		return option;
	}
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((answer == null) ? 0 : answer.hashCode());
		result = prime * result + option;
		return result;
	}
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Answer other = (Answer) obj;
		if (answer == null) {
			if (other.answer != null)
				return false;
		} else if (!answer.equals(other.answer))
			return false;
		if (option != other.option)
			return false;
		return true;
	}
	public void setOption(char option) {
		this.option = option;
	}
	public String getAnswer() {
		return answer;
	}
	public void setAnswer(String answer) {
		this.answer = answer;
	}
	@Override
	public String toString() {
		return "Answer [option=" + option + ", answer=" + answer + "]";
	}
	@Override
	public int compareTo(Answer o) {
		return Character.compare(this.option, o.option);
	}

	
	
}
