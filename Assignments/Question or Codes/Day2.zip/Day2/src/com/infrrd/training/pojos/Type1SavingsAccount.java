package com.infrrd.training.pojos;

public class Type1SavingsAccount extends SavingsAccount {

	public Type1SavingsAccount(double balance, String adhar) {
		super(balance, adhar);
	}
	
	public double withdraw(double amount) {
		balance=balance-amount;
		return balance;
	}

}
