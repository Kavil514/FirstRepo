package com.infrrd.training.pojos;

public abstract  class Account {

	private long accnum;// instance variable
	private String acc_holder_name;
	protected double balance;//child should access

	// Constructor Overloading
	public Account() {

	}
//actuators and mutators  setters and getters
	public Account(String acc_holder_name) {
		this.acc_holder_name = acc_holder_name;
	}

	public Account(double balance) {
		this.balance = balance;
	}

	public Account(String acc_holder_name, double balance) {
		this.acc_holder_name = acc_holder_name;
		this.balance = balance;
	}

	public Account(long accnum, String acc_holder_name, double balance) {
		this.accnum = accnum;
		this.acc_holder_name = acc_holder_name;
		this.balance = balance;
	}

	// setters
	public void setAccnum(long accnum) {
		this.accnum = accnum;
	}

	public void setAcc_holder_name(String acc_holder_name) {
		this.acc_holder_name = acc_holder_name;
	}

	public void setBalance(double balance) {
		this.balance = balance;
	}

	// getters
	public double getBalance() {
		return balance;
	}

	public String getAcc_holder_name() {
		return acc_holder_name;
	}

	public long getAccnum() {
		return accnum;
	}

	public String toString() {
		return accnum + " " + acc_holder_name + " " + balance;
	}
	
	

	//Method Overridding --will always happen in parent and child
	public final double deposit(int amount) {
		if (amount > 0) {
			balance = balance + amount;
		} else {
			System.out.println("Negetive amount is not acceptable");
		}
		return balance;
	}

	public  double withdraw(int amount) {
		if( balance - amount > 10000){
			balance=balance-amount;
		}else {
			System.out.println("min balance should maintain");
		}
		return balance;
	}

	

//	//voilating coding standards
//	public void sAccNum(long accnum) {
//		this.accnum=accnum;
//	}

}
