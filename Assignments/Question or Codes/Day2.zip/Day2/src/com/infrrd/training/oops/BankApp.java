package com.infrrd.training.oops;

import java.util.Scanner;

public class BankApp {
	static {
		System.out.println("Static Block");
	}
	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter Accnum ");
		//a1.accnum =sc.nextLong();
		System.out.println("Enter Account holder name");
		//a1.acc_holder_name=sc.next();
		System.out.println("Enter balance");
		//a1.balance = sc.nextDouble();
		Account a1=new Account(sc.nextLong(), sc.next(), sc.nextDouble());//declared and instantiated//default constructor
	
		//a1.setAccount(sc.nextLong(), sc.next(), sc.nextDouble());
		System.out.println("Object Created " +a1.getAccount());
		
//		Account a2=new Account();//
//		a2.accnum =178;
//		a2.acc_holder_name="Mohan";
//		a2.balance = 7899;
		
	}

}
