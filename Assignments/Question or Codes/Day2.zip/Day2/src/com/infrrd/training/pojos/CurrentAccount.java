package com.infrrd.training.pojos;

public class CurrentAccount extends Account {

	public CurrentAccount(long accnum, String acc_holder_name, double balance) {
		super(accnum, acc_holder_name, balance);
		// TODO Auto-generated constructor stub
	}

	

	public double withdraw(int amount) {
		if( balance - amount > 10000){
			balance=super.getBalance()-amount;
		}else {
			System.out.println("min balance should maintain");
		}
		return balance;
	}

}
