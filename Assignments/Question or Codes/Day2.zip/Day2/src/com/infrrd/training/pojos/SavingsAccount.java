package com.infrrd.training.pojos;

public class SavingsAccount extends Account {

	private String adharNum;
	public SavingsAccount(double balance, String adhar) {
		super(balance);
		this.adharNum=adhar;
	}

	public SavingsAccount(long accnum, String acc_holder_name, double balance,String adharNum) {
		super(accnum,acc_holder_name,balance);
		this.adharNum=adharNum;
	}
	
	//@Override
	public double withdraw(int amount) {
		if( balance - amount > 1000){
			balance=super.getBalance()-amount;
		}else {
			System.out.println("min balance should maintain");
		}
		return balance;
	}
	
	public String getMethod() {
		return "SavingsAccount";
	}

	
	

}
