package com.infrrd.training.pojos;

public class LoanAccount extends Account {

	public LoanAccount(double balance) {
		super(balance);
		// TODO Auto-generated constructor stub
	}

	@Override
	public double withdraw(int amount) {
		// TODO Auto-generated method stub
		return 0;
	}

}
