package com.infrrd.training.pojos;

public interface Shape {
	 final double PI =3.14;//final variables
	 double area();//public abstract methods
}

//SOLID
