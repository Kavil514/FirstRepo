package com.infrrd.training.pl;

import com.infrrd.training.pojos.Shape;

public class Circle implements Shape {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

	@Override
	public double area() {
		return PI*3*3;
	}

}
