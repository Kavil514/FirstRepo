package com.infrrd.training.pl;


class Parent{
	String name;
	
//	Parent(){
//		System.out.println("Parent Called");
//	}
	void method() {
		System.out.println("Parent Method called");
	}
	
	
}
class Child extends Parent{
	int id;
//	Child(){
//		System.out.println("Child Called");
//	}
	void method() {
		System.out.println("Child Method Called");
	}
	void method1() {
		System.out.println("Child only");
	}
}
public class InheritenceDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		//UpCasting
		Parent p=new Child();
		
		p.name = "Shwetha";
		System.out.println(p.name);
		p.method();
		
		((Child) p).method1();
		
		//DownCasting
		Child c=(Child) p;
		c.id=12;
		System.out.println(c.id);
		System.out.println(c.name);
		c.method();
	}

}
