package com.infrrd.training.pl;

import java.util.Scanner;
import com.infrrd.training.pojos.Account;
import com.infrrd.training.pojos.CurrentAccount;
import com.infrrd.training.pojos.SavingsAccount;

public class BankApp {

	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		
		Account acc;
		switch(sc.nextInt()) {
		case 1: acc=new SavingsAccount(123, null);
		System.out.println(acc.withdraw(567));
		//((SavingsAccount) acc).getMethod();
		break;
		case 2: acc=new CurrentAccount(0, null, 0);
		break;
		}
		
		
		SavingsAccount account=new SavingsAccount(6788, "S10000");
		account.setAccnum(5678999);
		account.setAcc_holder_name("Suma");
		System.out.println(account);
		do {
		System.out.println("1. Withdraw 2. Deposit 3.Get Balance 4.Exit");
		switch(sc.nextInt()) {
		case 1: System.out.println("Enter amount to withdraw");
		        System.out.println(account.withdraw(sc.nextInt()));
		        break;
		case 2: System.out.println("Enter amount to deposit");
				System.out.println(account.deposit(sc.nextInt()));
				break;
		case 3: System.out.println(account.getBalance());
			break;
		case 4: System.out.println("Thank You");
		        sc.close();
		        System.exit(0);
		default: System.out.println("Invalid");        
		}
		}while(true);
		
		
	//	Account.getDbConnection();
		
		
//		System.out.println("Enter Accnum ");
//		//a1.accnum =sc.nextLong();
//		System.out.println("Enter Account holder name");
//		//a1.acc_holder_name=sc.next();
//		System.out.println("Enter balance");
		//a1.balance = sc.nextDouble();
		//Account a1=new Account(sc.nextLong(), sc.next(), sc.nextDouble());//declared and instantiated//default constructor
	
		//a1.setAccount(sc.nextLong(), sc.next(), sc.nextDouble());
		//System.out.println("Object Created " +a1.getAccount());
		
//		Account a2=new Account();//
//		a2.accnum =178;
//		a2.acc_holder_name="Mohan";
//		a2.balance = 7899;
		
	}

}
