package com.infrrd.training.oops;

public class Account {
	//private only for class, itself
	//public inside package , subpackage, inside  project
	//if your not mentioning any access specifiers it is package accessablity--inside the package
	private long accnum;//instance variable
	private String acc_holder_name;
	private double balance;
	private static final String bank="SBI"; 
	
	//Parametrised Constructor
	public Account(long accnum,String acc_name, double bal){
		this.accnum=accnum;
		this.acc_holder_name=acc_name;
		balance=bal;
	}
	static {
		System.out.println("Static Block");
	}
	
	//setting value
	public void setAccount(long accnum,String acc_name, double bal) {//local variable
		this.accnum=accnum;
		this.acc_holder_name=acc_name;
		balance=bal;
		
		
	}
	 
	 public static void getDbConnection() {
		 System.out.println("Db Connected");
	 }
	
	//getting
	public  String getAccount() {
		return accnum+" "+acc_holder_name+" "+balance;
	}
	
}
