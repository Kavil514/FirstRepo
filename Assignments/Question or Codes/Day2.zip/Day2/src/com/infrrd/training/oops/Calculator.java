package com.infrrd.training.oops;

public class Calculator {
	// Method Overloading
	//1. Number of arguments are different
	//2. The datatype of the arguments are differ
	//3. Interchanging the datatype arguments
	public int add(int a,int b) {
		return a+b;
	}
	

	public float add(float a,float b) {
		System.out.println("float called");
		return a+b;
	}
	// add(10.98,89.04f);
	
	public float add(int a,float b) {
		System.out.println("2nd float");
		return a+b;
	}
	
	public float add(float a,int b) {
		System.out.println("1st float");
		return a+b;
	}
	
	public double add(double a,double b) {
		System.out.println("Double");
		return a+b;
	}
	public int add(int a,int b,int c) {
		return a+b+c;
	}
	
	public final float add(float a,int b,int c) {
		return a+b+c;
	}
	
	public String add(String a,int b) {
		return a+b;
	}
	public String add(int a,String b) {
		return a+b;
	}

	public static void main(String[] args) {
		Calculator c1=new Calculator();
		System.out.println(c1.add(23, 56));//int 2
		System.out.println(c1.add(34, 67, 89));//int 3
		System.out.println(c1.add(34.56f, 78.34f));//float
		System.out.println(c1.add(34.56, 67.89));//double
		System.out.println(c1.add(10.98,89.04f));
	}

}
