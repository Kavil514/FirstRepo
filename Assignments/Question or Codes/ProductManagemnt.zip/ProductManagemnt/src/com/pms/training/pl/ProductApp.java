package com.pms.training.pl;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.Scanner;

import com.pms.training.exceptions.BusinessException;
import com.pms.training.exceptions.UserNotFoundException;
import com.pms.training.pojos.User;
import com.pms.training.services.UserService;
import com.pms.training.services.UserServiceImpl;

public class ProductApp {

	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		System.out.println("How Many Users you want");
		UserService userService=new UserServiceImpl(sc.nextInt());
		do {
		System.out.println("1. Login \n 2. Signup \n 3. Exit");
		int choice=sc.nextInt();
		if(choice == 1) {
			System.out.println("Enter Username");
			String name=sc.next();
			System.out.println("Enter Password");
			String pass=sc.next();
			try {
			userService.login(name, pass);
			System.out.println("Login Success");
			System.out.println("For Which Index");
			int i=sc.nextInt();
			User newUser=userService.getUserByIndex(i);
			System.out.println("1. Update UserName 2. Update Password 3. Update Role");
			newUser.setUname(sc.next());
			newUser.setPassword(sc.next());
			newUser.setRole(sc.next());
			System.out.println("User Updated");
			User[] users;
			try {
				users = userService.getAllUsers();
				for(User u:users) {
					System.out.println(u);
				}
			} catch (BusinessException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
			
			}catch(UserNotFoundException u) {
				System.out.println(u.getMessage());
			}
			
			
		}else if(choice == 2){
			System.out.println("Enter the User Details 1. Dob, 2. Username 3.Password 4.Role 5.ContactNumber");
			String someDate =sc.next();
			DateTimeFormatter sd12=DateTimeFormatter.ofPattern("dd-MM-yyyy");
			
			LocalDate dob=LocalDate.parse(someDate,sd12);
			User user=new User(sc.next(), sc.next(), sc.next(), dob, sc.nextLong());
			try {
				userService.signUp(user);
				User[] users=userService.getAllUsers();
				for(User u:users) {
					System.out.println(u);
				}
			} catch (BusinessException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
		}else if(choice ==3) {
			System.out.println("Thank You");
			sc.close();
			System.exit(0);
		}else {
			System.out.println("invalid");
		}
		}while(true);

	}

}
