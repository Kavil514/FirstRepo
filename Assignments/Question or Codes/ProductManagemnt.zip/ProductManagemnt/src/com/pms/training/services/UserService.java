package com.pms.training.services;

import com.pms.training.exceptions.BusinessException;
import com.pms.training.exceptions.UserNotFoundException;
import com.pms.training.pojos.User;

public interface UserService {
	public boolean login(String uname,String password)throws UserNotFoundException;
	public void signUp(User user)throws BusinessException;
	public User[] getAllUsers()throws BusinessException;
	public User getUserByIndex(int index);
}
