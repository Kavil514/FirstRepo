package com.pms.training.services;

import com.pms.training.exceptions.BusinessException;
import com.pms.training.pojos.Catagory;
import com.pms.training.pojos.Product;

public interface ProductService {
	public Product getProduct(int index)throws BusinessException;
	public Product[] getAllProducts()throws BusinessException;
	public Catagory[] getAllCategories()throws BusinessException;
	public void addProduct(Product p)throws BusinessException;
	public void addCategory(Catagory c)throws BusinessException;
	public Product[] getAllProductsByCategory(Catagory cat)throws BusinessException;
}
