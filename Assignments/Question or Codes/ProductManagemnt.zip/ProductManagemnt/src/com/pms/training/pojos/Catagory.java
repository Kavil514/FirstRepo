package com.pms.training.pojos;

import java.util.Arrays;

public class Catagory {
	
	private int catid;
	private String categoryName;
	private Product[] products;
	
	public Catagory() {
		
	}
	
	public Catagory(int catid, String categoryName) {
		this.catid = catid;
		this.categoryName = categoryName;
	}
	public Catagory(int catid, String categoryName, Product[] products) {
		this.catid = catid;
		this.categoryName = categoryName;
		this.products = products;
	}
	public int getCatid() {
		return catid;
	}
	public void setCatid(int catid) {
		this.catid = catid;
	}
	public String getCategoryName() {
		return categoryName;
	}
	public void setCategoryName(String categoryName) {
		this.categoryName = categoryName;
	}
	public Product[] getProducts() {
		return products;
	}
	public void setProducts(Product[] products) {
		this.products = products;
	}
	@Override
	public String toString() {
		return "Catagory [catid=" + catid + ", categoryName=" + categoryName + ", products=" + Arrays.toString(products)
				+ "]";
	}
	
	
	
	
	
	

}
