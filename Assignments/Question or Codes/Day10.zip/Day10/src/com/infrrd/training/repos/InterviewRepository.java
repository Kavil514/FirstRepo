package com.infrrd.training.repos;

import java.util.ArrayList;
import java.util.List;

import com.infrrd.training.pojo.Candidate;

public class InterviewRepository {

	
	private static List<Candidate> candidateList;
	
	static {
		candidateList = new ArrayList<>();
		candidateList.add(new Candidate("Ramesh", "Java", "Pune", 15));
		candidateList.add(new Candidate("Suresh", "Java", "Banaglore", 25));
		candidateList.add(new Candidate("Ganesh", "C++", "Chennai", 0));
		candidateList.add(new Candidate("Gnanesh", "Java", "Pune", 5));
		candidateList.add(new Candidate("Mokesh", "C", "Pune", 1));
		candidateList.add(new Candidate("Soundarya", "Java", "Banaglore", 2));
		candidateList.add(new Candidate("Ramya", "Python", "Chennai", 5));
		candidateList.add(new Candidate("Nagma", "Java", "Banaglore", 0));
		candidateList.add(new Candidate("Somith", "Python", "Chennai", 0));
		candidateList.add(new Candidate("Sumith", "Java", "Pune", 4));
		candidateList.add(new Candidate("Suresh", "C++", "Banaglore", 10));
		candidateList.add(new Candidate("Avinash", "Java", "Pune", 1));
		candidateList.add(new Candidate("Amaresh", "C", "Pune", 12));
		candidateList.add(new Candidate("Jayesh", "Java", "Banaglore", 14));
		candidateList.add(new Candidate("Monika", "Python", "Chennai", 8));
		candidateList.add(new Candidate("Monish", "Python", "Banaglore", 9));
		candidateList.add(new Candidate("Manesh", "Java", "Chennai", 15));
		candidateList.add(new Candidate("Yumuna", "C++", "Banaglore", 25));
		candidateList.add(new Candidate("Gourav", "C", "Pune", 15));
	}
	
	public static  List<Candidate> getCandidateList(){
		return candidateList;
	}
}
