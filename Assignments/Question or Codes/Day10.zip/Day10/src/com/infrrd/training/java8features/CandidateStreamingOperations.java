package com.infrrd.training.java8features;

import java.util.Comparator;
import java.util.List;
import java.util.Map;
import java.util.Scanner;
import java.util.stream.Collectors;

import com.infrrd.training.pojo.Candidate;
import com.infrrd.training.repos.InterviewRepository;

public class CandidateStreamingOperations {

	public static void main(String[] args) {
//		1. List of  Pune Candidates 
//		for(Candidate can:candidates){
//			if(can.getCity().equals("Pune")){
//			Syso(can);
//			}
//		}
//		2.Count of Candidates based on City
//		3. Freshers from the list
//		4. Highest experienced Candidate
//		5. Count of Candidates based on TechnicalExpertise
//		6. Sort based on experienced
		Scanner sc=new Scanner(System.in);
		System.out.println("1. List of Candidates \n 2. Pune Candidates \n 3.Count of Candidates based on City \n" + 
				"4. Freshers from the list\n" + 
				"5. Highest experienced Candidate\r\n" + 
				"6. Count of Candidates based on TechnicalExpertise\r\n" + 
				"7. Sort based on experienced");
		List<Candidate> candidates=InterviewRepository.getCandidateList();
	do {
		int choice=sc.nextInt();
		switch(choice) {
		case 1: System.out.println("List of candidates");
		candidates.forEach(c->System.out.println(c));
		break;
		case 2: 
			System.out.println("Enter city");
			String cityName=sc.next();
			System.out.println("List of  Based on City ");
			candidates
					.stream()
					.filter(c -> c.getCity().equalsIgnoreCase(cityName))
					.forEach(c-> System.out.println(c));
			break;
		case 3:
			System.out.println("Candidate count per city");
			Map<Object, List<Candidate>> cityCount=candidates	
															.stream()
															.collect(Collectors.groupingBy(c->c.getCity()));
		for(Object city:cityCount.keySet()) {
			System.out.println(city+" "+cityCount.get(city).size());
		}
		
		break;
		case 4:System.out.println("Freshers from the list");
			List<Candidate> freshersList=candidates
												.stream()
												.filter(c-> c.getYearsOfExperience() == 0)
												.collect(Collectors.toList());
			//freshersList.forEach(System.out::println);		
			freshersList.forEach(s->System.out.println(s.getName()));
		break;
		case 5: System.out.println("Highest experienced Candidate");
		int maxYear= candidates.stream().map(c-> c.getYearsOfExperience()).max(Integer::compare).get();
		List<Candidate> experiecnedList=candidates
				.stream()
				.filter(c-> c.getYearsOfExperience() == maxYear)
				.collect(Collectors.toList());
				//comparator --> compare(candidate c1,Candidate c2);
				// (c1,c2) -> c1.getYearsOfExperice()-c2.getYearsOfExperice;
				//(c1,c2) -> c1.
		experiecnedList.forEach(System.out::print);
		break;
		case 6: System.out.println("Count of Candidates based on TechnicalExpertise");
		break;
		case 7: System.out.println("Sort based on experience");
	//	candidates.stream().sorted((can1,can2)->can1.getYearsOfExperience()-can2.getYearsOfExperience()).forEach(System.out::println);
		Comparator<Candidate> comp=(can1,can2)->can1.getYearsOfExperience()-can2.getYearsOfExperience();
		candidates
				.stream()
				.sorted(comp)
				.forEach(System.out::println);
		break;
		case 8: System.out.println("Thank You");
			sc.close();
			System.exit(0);
		default: System.out.println("Invalid");		
		}
	}while(true);
	}

}
