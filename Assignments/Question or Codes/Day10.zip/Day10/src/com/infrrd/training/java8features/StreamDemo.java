package com.infrrd.training.java8features;

import java.util.Arrays;
import java.util.IntSummaryStatistics;
import java.util.Iterator;
import java.util.List;
import java.util.Set;
import java.util.stream.Collectors;

public class StreamDemo {

	public static void main(String[] args) {
		List<String> names=Arrays.asList("Suma","Mona","Adi","Avi","Aki","Mam");
		System.out.println(names);
		List<String> filtered=names.stream().filter(s -> s.startsWith("A")).collect(Collectors.toList());
			System.out.println(filtered);	
			names.stream().filter(s -> s.startsWith("A")).forEach(s->System.out.println(s));
			
			List<String> filtered1=names.parallelStream().filter(s -> s.startsWith("A")).collect(Collectors.toList());
			System.out.println(filtered1);	
			
			names.stream().limit(4).forEach(s->System.out.print(s+"\t"));
			System.out.println("Limit with sort");
			names.stream().limit(4).sorted().forEach(s->System.out.print(s+"\t"));
			
			names.stream().sorted().limit(4).forEach(s->System.out.print(s));
			
			List<Integer> numbers=Arrays.asList(3,4,5,6,7,8,12,56,23,1,56,89,67);
			System.out.println();
			//IntSummaryStatistics stats= numbers.stream().mapToInt((x) -> x).summaryStatistics();
			System.out.println("Statistics");
			IntSummaryStatistics stats=new IntSummaryStatistics();
			Iterator<Integer> iterator=numbers.iterator();
			while(iterator.hasNext()) {
				stats.accept(iterator.next());
			}
			
			System.out.println(stats.getCount()+" "+stats.getAverage()+" "+stats.getSum());
			
			IntSummaryStatistics stats1=numbers.stream().mapToInt(c->c).summaryStatistics();
			
			System.out.println(stats1.getCount()+" "+stats1.getAverage()+" "+stats1.getSum());
	}

}
