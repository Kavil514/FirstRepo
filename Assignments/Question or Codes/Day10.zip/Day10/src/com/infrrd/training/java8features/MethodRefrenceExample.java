package com.infrrd.training.java8features;

import java.util.Scanner;
import java.util.function.Function;

public class MethodRefrenceExample {

	public static void main(String[] args) {
		long n,fact=0;
		Scanner sc=new Scanner(System.in);
		n=sc.nextLong();
		
		Function<Long,Long> factorial=MethodRefrenceExample::factCal;
		long result = factorial.apply(n);
		System.out.println(result);
		
	}
	
	static long factCal(long x) {
		long fact=1;
		for(int i=1;i<=x;i++) {
			fact =fact*i;
		}
		return fact;
	}

}
