package com.infrrd.training.java8features;

import java.util.Arrays;
import java.util.List;
import java.util.Optional;
import java.util.OptionalInt;
import java.util.stream.Collectors;
import java.util.stream.IntStream;
import java.util.stream.Stream;

public class LazyInvocationExample {
	private static int counter;
	
	private static void wasCalled() {
		counter++;
	}

	public static void main(String[] args) {
//	List<String> list=Arrays.asList("abc1","abc2","mnc","abc3");
	counter =0;
	
//	Stream<String> stream=list.stream().filter(e->{
//		wasCalled();
//		return list.contains("abc9");
//	});
//	
//	System.out.println(counter);
//	
//	List<String> newList=list.stream().filter(e->{
//		wasCalled();
//		return list.contains("abc9");
//	}).collect(Collectors.toList());
//	
//	System.out.println(counter+" after terminal operations");
//	
//	Optional<String> str=list.stream().filter(e->{
//				wasCalled();
//				return e.contains("abc");
//			}).map(e-> {
//				wasCalled();
//				return e.toUpperCase();
//				}).findAny();
	
//	System.out.println(counter+" after other terminal oertaion" + str.get());
	List<String> list=Arrays.asList("abc12","abc23","abc3","sdtreyr");
//	long size=list.stream().map(e-> {
//		wasCalled();
//		return e.substring(0, 3);
//	}).skip(2).count();
//	
//	System.out.println(counter);
//	
	//skip,filter, distinct
	long size2=list.stream().skip(2).map(e-> {
		wasCalled();
		return e.substring(0, 3);
	}).count();
	
	OptionalInt reduced=IntStream.range(1, 5).reduce((a,b)-> a+b);
	//1+2+3+4
	System.out.println(reduced);
	//System.out.println(counter);
	
	int red=IntStream.range(1, 5).reduce(10, (a,b)->a+b);
	System.out.println(red);
	
	
	int red2=Arrays.asList(1,2,3,4).parallelStream().reduce(10,(a,b)-> a+b , (a,b)->{
		return a+b;
	});
	
	System.out.println(red2);
	
	
	
	}

}
