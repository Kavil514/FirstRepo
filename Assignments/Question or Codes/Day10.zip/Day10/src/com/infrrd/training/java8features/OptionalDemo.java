package com.infrrd.training.java8features;

import java.util.Optional;

public class OptionalDemo {

	public static void main(String[] args) {
		String[] names=new String[10];
		Optional<String> checkNull=Optional.ofNullable(names[4]);
		if(checkNull.isPresent()) {
		String name=names[4].toUpperCase();
		System.out.println(name);
		}else {
			System.out.println("the requested string is not present");
		}
		
		String name=Optional.ofNullable(names[4]).orElse(new String("Shwetha"));
		System.out.println(name);
		
		OptionalDemo odp=new OptionalDemo();
		Integer a=null;
		Optional<Integer> valu1=Optional.ofNullable(a);
		Optional<Integer> b=Optional.of(new Integer(10));
		
		System.out.println(odp.sum(valu1, b));
	}

	public Integer sum(Optional<Integer> a, Optional<Integer> b) {
		System.out.println("The value 1 is "+a.isPresent()+" the value 2 is "+b.isPresent());
		Integer value1=a.orElse(new Integer(0));
		Integer value2= b.orElse(20);
		Integer value3=b.get();
		
		return value1+value2;
	}
}
