package com.infrrd.training;

import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.junit.jupiter.api.Assumptions.assumeFalse;
import static org.junit.jupiter.api.Assumptions.assumeTrue;

import org.junit.jupiter.api.Test;

public class AppTest {
	
	@Test
	public void testOnDev() {
		System.setProperty("ENV","DEV");
		assumeTrue("DEV".equals(System.getProperty("ENV")), AppTest::message);
		
	}
	
	@Test
	public void testOnProd() {
		System.setProperty("ENV","PROD");
		//assertTrue("DEV".equals(System.getProperty("ENV")));
		assumeTrue("DEV".equals(System.getProperty("ENV")), AppTest.message());
		
	}
	
	private static String message() {
		return "Test Exceution falied";	
	}

}
