package com.infrrd.training;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Disabled;
import org.junit.jupiter.api.Tag;
import org.junit.jupiter.api.Test;

class CalculatorTest {

	 Calculator cal=null;
	@BeforeAll
	static void setUpBeforeClass() throws Exception {
		
	}

	@AfterAll
	static void tearDownAfterClass() throws Exception {
	}

	@BeforeEach
	void setUp() throws Exception {
		cal=new Calculator();
	}

	@AfterEach
	void tearDown() throws Exception {
		cal=null;
	}

	@Test
	void testAdd() {
		//fail("Not yet implemented"); // TODO
		assertEquals(45, cal.add(23, 22));
	}

	@Test
	void testSub() {
		assertEquals(1, cal.sub(23, 22));
	}

	@Tag("PROD")
	//@Disabled
	@Test
	void testMul() {
		assertEquals(4, cal.mul(2, 2),"the multiplication have error");
		assertAll(
				()->assertEquals(0, cal.mul(2, 0)),
				()->assertEquals(2, cal.mul(2, 1)),
				()->assertEquals(6, cal.mul(2, 3)),
				()->assertEquals(20, cal.mul(2, 10)),
				()->assertEquals(0, cal.mul(2, 0))
			);
	}

	@Tag("DEV")
	@Test
	void testDiv() {
		assertThrows(ArithmeticException.class,  ()-> cal.div(20, 0),"divide by zero should throw");
		assertEquals(1, cal.div(12, 12));
		
		//assertEquals(0, cal.div(23, 0));
	}
	
	
	

}
