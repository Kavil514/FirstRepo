/**
 * 
 */
package com.infrrd.training;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

/**
 * @author shwet
 *
 */
class StringHelperTest2 {
	
	StringHelper str=null;

	/**
	 * @throws java.lang.Exception
	 */
	@BeforeAll
	static void setUpBeforeClass() throws Exception {
		System.out.println("Before Class");
	}

	/**
	 * @throws java.lang.Exception
	 */
	@AfterAll
	static void tearDownAfterClass() throws Exception {
	System.out.println("After all");
	}

	/**
	 * @throws java.lang.Exception
	 */
	@BeforeEach
	void setUp() throws Exception {
		str=new StringHelper();
		System.out.println("Before Each");
	}

	/**
	 * @throws java.lang.Exception
	 */
	@AfterEach
	void tearDown() throws Exception {
		System.out.println("After Each");
		str=null;
	}
	
	

	/**
	 * Test method for {@link com.infrrd.training.StringHelper#trunchateFirst2Positions(java.lang.String)}.
	 */
	@Test
	void testPositiveTrunchateFirst2Positions() {
		String actualResult=str.trunchateFirst2Positions("AABC");
		String expectedResult="BC";
		assertEquals(expectedResult, actualResult);
		assertEquals("Nil", str.trunchateFirst2Positions("ANil"));
		assertEquals("SOMA", str.trunchateFirst2Positions("SOMA"));
		assertEquals("BCD", str.trunchateFirst2Positions("ABCD"));
		assertEquals("DAA", str.trunchateFirst2Positions("ADAA"));
	}
	
	@Test
	void testNegativeTrunchateFirst2Positions() {
		String actualResult=str.trunchateFirst2Positions("AABC");
		String expectedResult="ABC";
		assertNotEquals(expectedResult, actualResult);
		assertNotEquals("ANil", str.trunchateFirst2Positions("ANil"));
		assertNotEquals("SOM", str.trunchateFirst2Positions("SOMA"));
		assertNotEquals("ABCD", str.trunchateFirst2Positions("ABCD"));
		assertNotEquals("ADAA", str.trunchateFirst2Positions("ADAA"));
	}

	/**
	 * Test method for {@link com.infrrd.training.StringHelper#first2CharsLast2CharsAreSame(java.lang.String)}.
	 */
	@Test
	void testFirst2CharsLast2CharsAreSame() {
		assertEquals(true, str.first2CharsLast2CharsAreSame("ShwethaSh"));
		assertFalse(str.first2CharsLast2CharsAreSame("InfrrdI"));
		assertTrue(str.first2CharsLast2CharsAreSame("In"));
		assertFalse(str.first2CharsLast2CharsAreSame("I"));
	}

	
	
}
