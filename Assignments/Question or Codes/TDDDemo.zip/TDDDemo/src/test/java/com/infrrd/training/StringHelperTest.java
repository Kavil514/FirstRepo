package com.infrrd.training;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertTrue;

import org.junit.jupiter.api.Test;

class StringHelperTest {

	StringHelper str=new StringHelper();
	@Test
	public void testTrunchateFirst2Positions() {
		//stubs
	String actualResult=str.trunchateFirst2Positions("AABC");
	String expectedResult="BC";
	assertEquals(expectedResult, actualResult);
	assertEquals("Nil", str.trunchateFirst2Positions("ANil"));
	assertEquals("SOMA", str.trunchateFirst2Positions("SOMA"));
	assertEquals("BCD", str.trunchateFirst2Positions("ABCD"));
	assertEquals("DAA", str.trunchateFirst2Positions("ADAA"));
	}
	@Test
	public void testFirst2CharsLast2CharsAreSame() {
		assertEquals(true, str.first2CharsLast2CharsAreSame("ShwethaSh"));
		assertFalse(str.first2CharsLast2CharsAreSame("InfrrdI"));
		assertTrue(str.first2CharsLast2CharsAreSame("In"));
		assertFalse(str.first2CharsLast2CharsAreSame("I"));
	}	
	//2.requirement

}
