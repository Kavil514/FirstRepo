package com.infrrd.training;

import static org.junit.jupiter.api.Assertions.*;

import java.util.Arrays;

import org.junit.jupiter.api.Tag;
import org.junit.jupiter.api.Test;

class ArrayTestCase {

	@Tag("DEV")
	@Test
	void test() {
		int[] arr1= {98,34,21,12,7,8,89};
		Arrays.sort(arr1);
		int[] expected= {7,8,12,21,34,89,98};
		assertArrayEquals(expected, arr1);
	}

	@Test
	//@Test(Expected=NUllpointerException.class)--junit 4
	void testArray() {
		int[] arr1= null;
		//Arrays.sort(arr1);
		int[] expected= {7,8,12,21,34,89,98};
		//assertArrayEquals(expected, arr1);
		assertThrows(NullPointerException.class,()-> Arrays.sort(arr1));
	}

}
