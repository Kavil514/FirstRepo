package com.infrrd.training;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Nested;
import org.junit.jupiter.api.Test;

class MathTest {

	private Calculator cal;
	
	@BeforeEach
	void initEach() {
		cal=new Calculator();
	}
	
	@Nested
	class AddTest{
		
		@Test
		void testAdding() {
			assertEquals(2, cal.add(1, 1));
		}
		
		@Test
		void testMul() {
			assertEquals(4, cal.mul(2, 2),"the multiplication have error");
			assertAll(
					()->assertEquals(0, cal.mul(2, 0)),
					()->assertEquals(2, cal.mul(2, 1)),
					()->assertEquals(6, cal.mul(2, 3)),
					()->assertEquals(20, cal.mul(2, 10)),
					()->assertEquals(0, cal.mul(2, 0))
				);
		}
		
	}
	
	
	@Nested
	class AddTest1{
		
		@Test
		void testAdding1() {
			assertEquals(2, cal.add(1, 1));
		}
		
		@Test
		void testMul1() {
			assertEquals(4, cal.mul(2, 2),"the multiplication have error");
			assertAll(
					()->assertEquals(0, cal.mul(2, 0)),
					()->assertEquals(2, cal.mul(2, 1)),
					()->assertEquals(6, cal.mul(2, 3)),
					()->assertEquals(20, cal.mul(2, 10)),
					()->assertEquals(0, cal.mul(2, 0))
				);
		}
		
	}
	
	
//	@Test
//	void testMulExample() {
//		assertEquals(4, cal.mul(2, 2),"the multiplication have error");
//		assertAll(
//				()->assertEquals(0, cal.mul(2, 0)),
//				()->assertEquals(2, cal.mul(2, 1)),
//				()->assertEquals(6, cal.mul(2, 3)),
//				()->assertEquals(20, cal.mul(2, 10)),
//				()->assertEquals(0, cal.mul(2, 0))
//			);
//	}

}
