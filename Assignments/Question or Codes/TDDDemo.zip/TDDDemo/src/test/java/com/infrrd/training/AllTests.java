package com.infrrd.training;

import org.junit.platform.suite.api.ExcludeTags;
import org.junit.platform.suite.api.IncludePackages;
import org.junit.platform.suite.api.SelectPackages;
import org.junit.runner.RunWith;
import org.junit.runners.Suite;
import org.junit.runners.Suite.SuiteClasses;

@RunWith(Suite.class)
@SuiteClasses({CalculatorTest.class, ArrayTestCase.class})
@SelectPackages("com.infrrd.training")
@IncludePackages("com.infrrd.training")
@ExcludeTags("PROD")
public class AllTests {

}
