package com.infrrd.training.basic;

import java.util.Arrays;

public class ArrayDemo {
	
	static void display(){
		System.out.println("Static method");
	}
	
	void min(int[] arr) {
		int min=arr[0];
		for(int i=1;i<arr.length;i++) {
			if(min>arr[i])
				min=arr[i];
			
		}
		System.out.println("Minimum value "+min);
	}

	public static void main(String[] args) {
	ArrayDemo.display();
		
		//group of homogeneous data
		//index starts from 0
		//length starts from 1
		int num=10;
		//int arr[] = new int[10];//declaring  and instantiation
		int[] arr=new int[10];
		arr[0] =10;//init
		arr[1] =78;
		arr[2]=89;
		arr[3]=12;
		arr[4]=18;
		arr[5]=89;
		//traversing an array
		for(int i=0;i<arr.length;i++) {
		System.out.print(arr[i]+"\t");
		}
		System.out.println();
		//java 5 enhanced for loop
		for(int a:arr) {
			System.out.print(a+"\t");
		}
		
		System.out.println("2nd array");
		int arr1[] = {89,87,23,4,52,12,8};//declaring, instantiation and init
		for(int a:arr1) {
			System.out.print(a+"\t");
		}
		
		ArrayDemo ad=new ArrayDemo();
		ad.min(arr1);
		
		int[][] tDArr= new int[3][3];
		
		int[][] twoDarr= {{23,45,67},{28,55,78},{29,34,69}};
		
		for(int i=0;i<twoDarr.length;i++) {
			for(int j=0;j<twoDarr.length;j++) {
			System.out.print(twoDarr[i][j] +"\t");
			}
			System.out.println();
		}
		
		
		System.out.println("Enhanced For loop");
		for(int a[]:twoDarr) {
			for(int b:a) {
				System.out.print(b +"\t");
			}
			System.out.println();
		}
		
		char[] cp= {'d','f','e','g','h','i','k','l','a','b'};
		char cpt[] = new char[20];	
		cpt[0]='u';
		cpt[1]='s';
		
		//copy array values from one to another
		System.arraycopy(cp, 2, cpt, 1, 6);
		
		System.out.println(String.valueOf(cpt));
		//cloning array
		char cArr[]= cpt.clone();
		System.out.println(String.valueOf(cArr));
		
		cpt[5]='z';
		
		System.out.println(String.valueOf(cpt));
		System.out.println(String.valueOf(cArr));
		
		Arrays.sort(cArr);
		System.out.println(String.valueOf(cArr));
	// com.nameofthecompany.project.subproject.layer
		//org.nameofthecompany.project.subproject.layer
		// java.lang ,  java.util, java.io
		//javax.
		
	}
	

}
