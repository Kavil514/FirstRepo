package com.infrrd.training.basic;

public class VariableDeclaration {
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		byte b=10; // 1 byte
		short sh=1234;//2 bytes
		int num1= 123456; //4 bytes
		long num2=1234567890l;// 8 bytes
		System.out.println(b+" "+sh+" "+num1+" "+num2);
		float num3=167f;
		double num4=167;
		System.out.println(num3+" "+num4);
		
		char ch=171;//2 bytes
		System.out.println(ch);
		//65 66 97
		
		char ch1='\u0041';
		System.out.println(ch1);
		
		boolean bo = false;//1 bit
		System.out.println(bo);
	
	//-128 to 127
		byte byteData = 126;
		System.out.println(byteData);
		
		byteData++;
		System.out.println(byteData);
		
	//overflow
		byteData++;
		System.out.println(byteData);
		
		byteData++;
		System.out.println(byteData);
		
		int a=10;
		float ba=a;//widening
		
		System.out.println(a);
		System.out.println(ba);
		
		float f=10.7f;
		//int m=f;//compilation error
		int m = (int)f;//Narrowing(TypeCasting)
		
		System.out.println(m);
		
		final float PI=3.14f;//constant
		System.out.println(PI);
//		PI++;
//		System.out.println(PI);
	}
	
	

}
