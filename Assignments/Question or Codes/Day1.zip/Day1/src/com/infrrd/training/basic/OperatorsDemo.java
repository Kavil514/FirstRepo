package com.infrrd.training.basic;

public class OperatorsDemo {

	public static void main(String[] args) {
			
		int i=10;
		int j= -11;
		
		//System.out.println(i++ + ++i);
		//System.out.println(--i+i--);
		
		System.out.println(~i);//-11
		System.out.println(~j);//10
		
		System.out.println(10<<2);// 10*2^2 = 10*4
		System.out.println(10<<3);// 10*2^3 = 80
		
		System.out.println(10>>2); //10/2^2 = 10/4 = 2
		
		System.out.println(i>j || i++ < j);
		
		int a=34;
		int b=89;
		boolean min = (a<b)?true:false;
		System.out.println(min);
		
		//short hand
		a=a+b;
		a+=b;
		
		a=a*b;
		a*=b;
		
		a/=2;
		
		
		
		

	}

}
