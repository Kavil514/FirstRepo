package com.infrrd.training.basic;

public class MathDemo {

	public static void main(String[] args) {
		double num1=546;
		double num2 =987;
		
		System.out.println("Max "+Math.max(num1, num2));
		System.out.println(" Sqrt "+Math.sqrt(num1));
		System.out.println("Cube "+Math.cbrt(num1));
		System.out.println("Log value "+Math.log(num1));

	}

}
