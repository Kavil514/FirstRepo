package com.infrrd.training.basic;

public class UnConditionalExample {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
//int i=0;
//		
//		while(i<10) {
//			if(i==4)
//				break;
//			System.out.println("While break Iteartion "+ ++i);
//		}
//		
//		 i=0;
//			
//			while(i<10) {
//				if(i==4)
//					continue;
//				System.out.println("While continue Iteartion "+ ++i);
//			}

		//looping   initialization, checking the condition , incrementation/decremenation
		int  i=5;
		
		while(i<5) {
			System.out.println("While Iteartion "+ ++i);
		}
		
	 i=5;
	 do {
		 System.out.println("DO Iteartion "+ ++i);
	 }while(i<5);
	
	
	for(i=0;i<5;++i) {
		System.out.println("For iteration " + i);
	}
	
	}
}
