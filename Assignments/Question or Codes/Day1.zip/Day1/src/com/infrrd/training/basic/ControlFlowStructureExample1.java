package com.infrrd.training.basic;

import java.util.Scanner;

public class ControlFlowStructureExample1 {

	public static void main(String[] args) {
		// Conditional -- if, if else, if else-if, switch
		// unconditional -- break, continue, label
		// looping -- while, do while, for
		// System.in;
//		System.out.println("Output");
//		System.err.println("Error");
		// commandline arguments
		// System.out.print("Welcome to Java World"+args[0]);
		// runtime arguments
		Scanner sc = new Scanner(System.in);
		System.out.println("Welcome to Calc");
		while(true) {
		System.out.println("enter num1 and num2");
		int num1 = sc.nextInt();
		int num2 = sc.nextInt();
		inner:
		while (true) {
			System.out.println("1. Add \n 2.Sub \n 3. Mul \n 4.Div \n 5.Greater \n 6.Lesser \n 7.Exit \n 8.Go Back");
			switch (sc.nextInt()) {
			case 1:
				System.out.println(" Add Result " + (num1 + num2));
				break;
			case 2:
				System.out.println("Sub Result " + (num1 - num2));
				break;
			case 3:
				System.out.println("Multiplication Result " + (num1 * num2));
				break;
			case 4:
				System.out.println("Division Result " + num1 / num2);
				break;
			case 5:
				if (num1 > num2) {
					System.out.println(num1 + " is greater");
				} else {
					System.out.println(num2 + " is greater");
				}
				break;
			case 6:
				if (num1 < num2) {
					System.out.println(num1 + " is Smaller");
				} else {
					System.out.println(num2 + " is Smaller");
				}
				break;
			case 7:
				System.out.println("Thank you");
				sc.close();
				System.exit(0);
			case 8: break inner;	
			default:
				System.out.println("Invalid Option");
			}
		}
		}
	}

}
