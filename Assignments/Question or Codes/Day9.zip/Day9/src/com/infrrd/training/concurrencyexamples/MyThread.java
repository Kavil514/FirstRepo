package com.infrrd.training.concurrencyexamples;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Iterator;
import java.util.List;
import java.util.Vector;
import java.util.concurrent.CopyOnWriteArrayList;



public class MyThread extends Thread{

	static List<String> l=new CopyOnWriteArrayList<String>();
	
	public void run() {
		try {
			Thread.sleep(1000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		System.out.println("Thread is accessing");
		l.add("String");
	}
	
	
	public static void main(String[] args)throws InterruptedException {
		l.add("join");
		l.add("fork");
		l.add("execute");
		
		
		MyThread mt=new MyThread();
		mt.start();
		
		mt.join();
		
		MyThread mt1=new MyThread();
		mt1.start();
		Iterator<String> itr=l.iterator();
		while(itr.hasNext()) {
			String s=itr.next();
			System.out.println("Main thread executing "+s);
			Thread.sleep(2000);
		}
		
		System.out.println(l);
		
		l.remove(2);
		
//		Iterator<String> itr1=l.iterator();
//		while(itr1.hasNext()) {
//		itr1.remove();
////			String s=itr.next();
////			System.out.println("Main thread executing "+s);
////			Thread.sleep(2000);
//		}
		
		System.out.println(l);
		
		
		

	}

}
