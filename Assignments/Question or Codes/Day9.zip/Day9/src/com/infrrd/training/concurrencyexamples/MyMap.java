package com.infrrd.training.concurrencyexamples;

import java.util.*;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ConcurrentMap;

public class MyMap extends Thread {
	
	static Map<Integer, String> map=new ConcurrentHashMap<>();
	
	public void run() {
		try {
			Thread.sleep(1000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		System.out.println("Thread is accessing");
		map.putIfAbsent(109, "sdf");
	}

	public static void main(String[] args) throws InterruptedException {
		map.put(109, "Suma");
		map.put(104, "Uma");
		map.put(105, "Sma");
		map.put(107, "Sa");
		MyMap m1=new MyMap();
		m1.start();
		Set s=map.keySet();
		Iterator itr=s.iterator();
		while(itr.hasNext()) {
			int i=(int)itr.next();
			System.out.println("Main Thread is iterating "+ i);
			Thread.sleep(3000);
		}

		System.out.println(map);
	}

}
