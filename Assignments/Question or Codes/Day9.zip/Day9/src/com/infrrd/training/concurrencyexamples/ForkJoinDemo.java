package com.infrrd.training.concurrencyexamples;

import java.util.List;
import java.util.concurrent.ForkJoinPool;
import java.util.concurrent.TimeUnit;

public class ForkJoinDemo {

	public static void main(String[] args) {
	
		ForkJoinPool pool=new ForkJoinPool();
		
		FolderProcessor fp1=new FolderProcessor("F:\\trainings\\capgemini", ".txt");
		FolderProcessor fp2=new FolderProcessor("F:\\SpringPeople\\Infrrd", ".txt");
		FolderProcessor fp3=new FolderProcessor("F:\\SpringPeople\\contents", ".pdf");
		
		pool.execute(fp1);
		pool.execute(fp2);
		pool.execute(fp3);
		
		do {
			
			System.out.println("=======================================");
			System.out.println("Parallelism "+pool.getParallelism());
			System.out.println("Active Threads "+ pool.getActiveThreadCount() );
			System.out.println("Task count "+pool.getQueuedTaskCount());
			System.out.println("Steal Count "+pool.getStealCount());
			
			try {
				TimeUnit.SECONDS.sleep(1);
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}while((!fp1.isDone()) || (!fp2.isDone()) || (!fp3.isDone()));
		
		pool.shutdown();
		
		List<String> results;
		results=fp1.join();
		System.out.println(" Capgemini Folder result "+results.size());
		results=fp2.join();
		System.out.println("Infrrd Folder result "+ results.size());
		
		results=fp3.join();
		System.out.println("Content folder "+results.size());
	}
	
	

}
