package com.infrrd.training.pojos;

public class ElectronicProduct extends Product {

	private String brand;
	public ElectronicProduct(int pid, String pname, double cost, int qty,String brand) {
		super(pid, pname, cost, qty);
		this.setBrand(brand);
	}

	public String getBrand() {
		return brand;
	}

	public void setBrand(String brand) {
		this.brand = brand;
	}

	
	@Override
	public String toString() {
		return "ElectronicProduct [brand=" + brand + ", getBrand()=" + getBrand() + ", getPid()=" + getPid()
				+ ", getPname()=" + getPname() + ", getCost()=" + getCost() + ", getQty()=" + getQty() + ", toString()="
				+ super.toString() + ", getClass()=" + getClass() + ", hashCode()=" + hashCode() + "]";
	}


	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

}
