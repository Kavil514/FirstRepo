package com.infrrd.training.ios;

import java.io.File;
import java.io.IOException;

public class IOExample1 {

	public static void main(String[] args) {
		FileOperations fileOperations=new FileOperations();
		File f=new File("example.txt");
		try {
			fileOperations.writeToFile(f);
		} catch (Exception e) {
			e.printStackTrace();
		}
		System.out.println("Done");
		try {
			fileOperations.readFromFile(f);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		System.out.println("Completed");
	}

}
