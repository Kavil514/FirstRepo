package com.infrrd.training.java8;

interface Calculator{
	public double calc(int a,int b);
}

public class LambdaDemo {

	public static void main(String[] args) {
		Calculator c1= (a,b) ->  a+b;
		System.out.println(c1.calc(12, 34));
		Calculator c2=(m,n) -> m*n;
		System.out.println(c2.calc(67, 98));
		Calculator c3=(a,b) -> a-b;
		System.out.println(c3.calc(34, 67));
	}

}
