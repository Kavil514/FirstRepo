package com.infrrd.training.ios;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;

import com.infrrd.training.pojos.ElectronicProduct;
import com.infrrd.training.pojos.Product;

public class ObjectFileOperations {

	public void writeToFile(File file) throws IOException {
		Product p=new Product(1, "Laptop", 3450, 100);
		FileOutputStream fos=new FileOutputStream(file);
//	String s=	p.toString();
//	fos.write(s.getBytes());
		ObjectOutputStream oos=new ObjectOutputStream(fos);
		oos.writeObject(p);
		oos.flush();
		fos.flush();
		oos.close();
		fos.close();
	}
	
	public void readFromFile(File file) throws IOException, ClassNotFoundException {
		FileInputStream fis=new FileInputStream(file);
		ObjectInputStream ois=new ObjectInputStream(fis);
		Product p=(Product)ois.readObject();
		System.out.println(p);
		fis.close();
		
		
	}
}
