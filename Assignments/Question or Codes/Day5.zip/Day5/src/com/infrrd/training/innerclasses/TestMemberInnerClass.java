package com.infrrd.training.innerclasses;

public class TestMemberInnerClass {
	
	private int data=90;
	public void display1() {
	class Inner{
		int data=78;
		TestMemberInnerClass tn=new TestMemberInnerClass();
		void display() {
			System.out.println(tn.data);
		}	
	}
	Inner i=new Inner();
	i.display();
	}

	public static void main(String[] args) {
		
		TestMemberInnerClass obj=new TestMemberInnerClass();
		//TestMemberInnerClass.Inner in=obj.new Inner();
		obj.display1();

	}

}
