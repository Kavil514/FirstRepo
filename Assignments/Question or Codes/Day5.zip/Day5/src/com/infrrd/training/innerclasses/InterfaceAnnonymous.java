package com.infrrd.training.innerclasses;

interface Shape{
	public double area(int r);
}


public class InterfaceAnnonymous {
	 Shape s1=new Shape() {
			@Override
			public double area(int r) {
				return 3.14*r*r;
			}
		};
}
//public static void example() {
//	 s1=new Shape() {
//		@Override
//		public double area(int r) {
//			return 3.14*r*r;
//		}
//	};
	
//}
	
//	public static void main(String[] args) {
//		Shape s1=new Shape() {
//			@Override
//			public double area(int r) {
//				return 3.14*r*r;
//			}
//		};
//		
//		System.out.println(s1.area(23));
//		
//		Shape s2=new Shape() {
//			@Override
//			public double area(int r) {
//				// TODO Auto-generated method stub
//				return 67.9*r;
//			}	
//			
//		};
//		
//		System.out.println(s2.area(23));
//		
//		
//		Shape s3=new Shape() {
//			public double area(int r) {
//				return r;
//			}
//		};
//
//	}

//}
