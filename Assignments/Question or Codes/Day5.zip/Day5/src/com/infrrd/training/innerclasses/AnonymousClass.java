package com.infrrd.training.innerclasses;

abstract class Account{
	 double balance=1900;
	abstract double withdraw(int amount);
}
public class AnonymousClass {

	public static void main(String[] args) {
		Account a1=new Account() {
			@Override
			double withdraw(int amount) {
				// TODO Auto-generated method stub
				return balance-amount;
			}		
		};
		
		System.out.println(a1.withdraw(200));
		
		Account a2=new Account() {
			@Override
			double withdraw(int amount) {
				// TODO Auto-generated method stub
				return balance-amount;
			}		
		};
		
		System.out.println(a2.withdraw(200));


	}

}
