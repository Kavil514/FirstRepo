package com.infrrd.training.java8;

@FunctionalInterface
interface Figure{
	public double area();
	//public void exa();
	public default String color(String color) {
		return color;
	}
	public default String color1(String color) {
		return color;
	}
	public static void getStaticMethod() {
		System.out.println("Staoc method in interface");
	}
}

interface Xyz{
	
	public default String color(String color) {
		return color;
	}
}

class Triangle implements Figure,Xyz{
private int b;
private int h;
	public Triangle(int base,int height) {
		this.b=base;
		this.h=height;
	}
	
	@Override
	public double area() {
		// TODO Auto-generated method stub
		return 0.5*b*h;
	}

	@Override
	public String color(String color) {
		
		return Figure.super.color(color);
	}
}

class Circle implements Figure{
	private double r;
	Circle(double r){
		this.r=r;
	}
	@Override
	public double area() {
		// TODO Auto-generated method stub
		return Math.PI*r*r;
	}
	
}


public class InterfaceChanges {

	public static void main(String[] args) {
		Figure f1=new Triangle(34, 78);
		Figure f2=new Circle(45);
//		System.out.println(f1.area());
//		System.out.println(f2.area());
		Figure.getStaticMethod();
		Triangle t1=new Triangle(34, 345);
System.out.println(f1.color("Red")+" Traingle with the area " +f1.area());
System.out.println(f2.color("Blue")+" Cicle with  the area "+f2.area());
	}

}
