package com.infrrd.training.java8;

import java.util.function.*;

public class PreDefinedFunctionalInterface {

	public static void main(String[] args) {
		//Supplier--> no Arg
		//Consumer--> with one arg, no return
		//BiConsumer --> with two args with no return
		//Predicate --> with one arg , boolean return
		//BiPredicate--> with two arg, boolean return
		//Function --> with one argument, and one return type argument
		//BiFunction --> with two args and one return type
		//BinaryOperator--> two operands of same data type with same return
		
		//1. create calculator with FI
		//    1. With your own FI
		//    2. With BiFunction
		//    3. With BinaryOperator
		//operations --> add, sub,div,mul,leftshift
		
		
		BinaryOperator<Integer> bo=(n,m)-> n+m;
		System.out.println(bo.apply(34, 78));
		
		Supplier sup=()->"Just Supplier";
		System.out.println(sup.get());
		
		Predicate<Integer> pre=(n)-> n>3;
		System.out.println(pre.test(12));
		
		Predicate<String> pre1=(n)-> n.equals("Infrrd");
		System.out.println(pre1.test("Infrrd"));
		
		
		BiPredicate<Integer, Integer> biPre=(n,m)-> n>m;
		System.out.println(biPre.test(34, 78));
		
		BiFunction<Integer, Integer,Integer> func=(a,b)-> a+b;
		System.out.println(func.apply(34,78));
	}

}
