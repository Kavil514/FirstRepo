package com.infrrd.training.innerclasses;

public class ExampleDemo  extends InterfaceAnnonymous{

	ExampleDemo(){
		System.out.println(s1.area(423));
	}	
	
	public static void main(String[] args) {
		

	}

}
