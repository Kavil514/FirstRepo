package com.infrrd.training.ios;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;

public class FileOperations {

	public void writeToFile(File file) throws IOException {
		String data="Data to file";
		FileOutputStream fos=new FileOutputStream(file,true);
		fos.write(data.getBytes());
		fos.flush();
		fos.close();
	}
	
	public void readFromFile(File file) throws IOException {
		FileInputStream fis=new FileInputStream(file);
		int i=0;
		while((i=fis.read()) != -1) {
		System.out.print((char)i);
		}
		fis.close();
		
		
	}
}
