package com.pms.training.services;

import com.pms.training.exceptions.BusinessExceptions;
import com.pms.training.pojos.Category;
import com.pms.training.pojos.Product;

public class ProductServiceImplementation implements ProductService
{
	private static int productCount=0;
	private static int categoryCount=0;
	@Override
	public Product getProduct(int pid)throws BusinessExceptions
	{
		Product[] allProducts=getAllProducts();
		Product product=null;
		boolean status=false;
//		for(int count=0;count<productCount;count++)
//		{
//			if(allProducts[count].getPid()==pid)
//			{
//				status=true;
//				product=allProducts[count];
//				break;
//			}
//		}
		
		for(Product p:allProducts)
		{
			if(p!=null&&p.getPid()==pid)
			{
				status=true;
				product=p;
			}
		}
		if(!status)
		{
			throw new BusinessExceptions("Product Not Found!");
		}
		return product;
	}
	
	@Override
	public Product[] getAllProducts()throws BusinessExceptions
	{
		Category cat=new Category();
		if(productCount==0)
			throw new BusinessExceptions("No Products!");
		return cat.getProducts();
	}
	
	@Override
	public Category[] getAllCategories()throws BusinessExceptions
	{
		Category allCategory=new Category();
		if(categoryCount==0)
			throw new BusinessExceptions("No Categories!");
		return allCategory.getAllCategories();
		
	}
	
	@Override
	public void addProduct(Product newProduct)throws BusinessExceptions
	{
		Product[] products;
		try {
			products=getAllProducts();
		}catch(BusinessExceptions e)
		{
			products=new Product[20];
		}
		for(Product p:products)
		{
			if(p!=null && p.getPid()==newProduct.getPid())
			{
				throw new BusinessExceptions("Product Already Exists!");
			}
		}
		if(productCount<=products.length)
		{
			products[productCount]=newProduct;
			productCount++;
			new Category().setProducts(products);
		}
	}
	
	@Override 
	public Category getCategory(int catid)throws BusinessExceptions
	{
		Category[] allCategories=getAllCategories();
		Category category=null;
		boolean status=false;
//		for(int count=0;count<categoryCount;count++)
//		{
//			if(allCategories[count].getCatid()==catid)
//			{
//				status=true;
//				category=allCategories[count];
//				break;
//			}
//		}
		for(Category c:allCategories)
		{
			if(c!=null && c.getCatid()==catid)
			{
				status=true;
				category=c;
				break;
			}
		}
		if(!status)
		{
			throw new BusinessExceptions("Category Not Found!");
		}
		return category;
	}
	
	
	@Override
	public void addCategory(Category newCategory)throws BusinessExceptions
	{
		Category[] allCategories;
		try {
			allCategories=getAllCategories();
		}catch(BusinessExceptions e)
		{
			allCategories=new Category[10];
		}
//		for(int count=0;count<categoryCount;count++)
//		{
//			c=allCategories[count];
//			if(c.getCatid()==newCategory.getCatid())
//				throw new BusinessExceptions("Category Already Exists!");
//		}
		for(Category c:allCategories)
		{
			if(c!=null && c.getCatid()==newCategory.getCatid())
			{
				throw new BusinessExceptions("Category Already Exists!");
			}
		}
		if(categoryCount<=allCategories.length)
		{
			allCategories[categoryCount]=newCategory;
			categoryCount++;
			new Category().setCategories(allCategories);
		}
	}

	@Override
	public Product[] getAllProductsByCategory(Category cat) throws BusinessExceptions {
		Product[] productsByCategory;
		Product[] allProducts=getAllProducts();
		productsByCategory=new Product[allProducts.length];
		boolean status=false;
		int count=0;
//		for(count=0;count<productCount;count++)
//		{
//			p=allProducts[count];
//			if(p.getCategory().getCatid()==cat.getCatid())
//			{
//				productsByCategory[count]=p;
//				status=true;
//			}
//		}
		for(Product p:allProducts)
		{
			if(p!=null && p.getCategory().getCatid()==cat.getCatid())
			{
				productsByCategory[count]=p;
				count++;
			}
				
		}
		
		if(!status)
		{
			throw new BusinessExceptions("No Product by that category!");
		}
		return productsByCategory;
	}
}

