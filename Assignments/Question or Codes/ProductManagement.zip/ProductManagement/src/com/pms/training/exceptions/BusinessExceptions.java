package com.pms.training.exceptions;

public class BusinessExceptions extends Exception {
		public BusinessExceptions(String message)
		{
			super(message);
		}
}
