package com.pms.training.pojos;


public class Category {
	
	private int catid;
	private String categoryName;
	private static Product[] products;
	private static Category categories[];
	
	public Category()
	{
		
	}
	public Category(int catid, String categoryName) {
		super();
		this.catid = catid;
		this.categoryName = categoryName;
	}


	public Category(int catid, String categoryName, Product[] products) {
		super();
		this.catid = catid;
		this.categoryName = categoryName;
		this.products = products;
	}
	public int getCatid() {
		return catid;
	}
	public void setCatid(int catid) {
		this.catid = catid;
	}
	public String getCategoryName() {
		return categoryName;
	}
	public void setCategoryName(String categoryName) {
		this.categoryName = categoryName;
	}
	public Product[] getProducts() {
		return products;
	}
	public void setProducts(Product[] products) {
		this.products = products;
	}
	public Category[] getAllCategories()
	{
		return this.categories;
	}
	
	public void setCategories(Category[] categories) {
		this.categories = categories;
	}
	@Override
	public String toString() {
		return "Category [catid=" + catid + ", categoryName=" + categoryName+"]";
	}
	 
}
