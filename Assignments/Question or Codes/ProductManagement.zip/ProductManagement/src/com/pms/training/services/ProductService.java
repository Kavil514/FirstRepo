package com.pms.training.services;

import com.pms.training.exceptions.BusinessExceptions;
import com.pms.training.pojos.Category;
import com.pms.training.pojos.Product;

public interface ProductService {
	public Product getProduct(int pid)throws BusinessExceptions;
	public Product[] getAllProducts()throws BusinessExceptions;
	public Category[] getAllCategories()throws BusinessExceptions;
	public void addProduct(Product p)throws BusinessExceptions;
	public void addCategory(Category c)throws BusinessExceptions;
	public Product[] getAllProductsByCategory(Category cat)throws BusinessExceptions;
	public Category getCategory(int catid)throws BusinessExceptions;
}
