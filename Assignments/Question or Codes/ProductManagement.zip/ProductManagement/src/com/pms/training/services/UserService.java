package com.pms.training.services;
import com.pms.training.exceptions.UserNotFoundException;
import com.pms.training.exceptions.BusinessExceptions;
import com.pms.training.pojos.User;

public interface UserService {
	
	public boolean login(String uname, String password)throws UserNotFoundException;
	public void signUp(User user)throws BusinessExceptions;
	public User[] getAllUsers()throws BusinessExceptions;
	public User getUserByNameAndPass(String name, String password);
	
}
