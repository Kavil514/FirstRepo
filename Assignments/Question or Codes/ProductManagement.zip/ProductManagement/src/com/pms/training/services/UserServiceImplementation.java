package com.pms.training.services;

import com.pms.training.exceptions.BusinessExceptions;
import com.pms.training.exceptions.UserNotFoundException;
import com.pms.training.pojos.User;

public class UserServiceImplementation implements UserService {
	User[] users=null;
	private int count=0;
	private static int userCount=0;
	public UserServiceImplementation(int size)
	{
		users=new User[size];
		userCount=size;
		
	}
	@Override
	public boolean login(String uname, String password) throws UserNotFoundException {
		boolean status=false;
		for(User user:users)
		{
			if(user!=null && user.getUname().equals(uname) && user.getPassword().equals(password))
			{
				status=true;
			}
		}
		if(!status)
			{
				throw new UserNotFoundException("Invalid Username or Password");
			}
		return status;
	}

	@Override
	public void signUp(User user) throws BusinessExceptions {
//		for(int i=count;i<users.length;i++)
//		{
		if(users==null||count<=users.length-1) {
			if(user.getUname().matches("[A-Z][A-Za-z]*"))
			{
				if(user.getPassword().matches("(?=.*[0-9])(?=.*[A-Z])(?=.*[a-z]).{8}")) 
				{
					if(user.getRole().equalsIgnoreCase("user")||user.getRole().equalsIgnoreCase("admin"))
					{
						users[count]=user;
						count++;
					}
					else
					{
						throw new BusinessExceptions("Invalid Role");
					}
				}
				else
				{
					throw new BusinessExceptions("Invalid Password(Combination of upper, lower and number with 8 characters)");
				}
			}else
			{
				throw new BusinessExceptions("Invalid Username");
			}
		}
	else {
		throw new BusinessExceptions("Database full!");
	}
	}
//	}

	@Override
	public User[] getAllUsers() throws BusinessExceptions{
		// TODO Auto-generated method stub
		return users;
	}
	@Override
	public User getUserByNameAndPass(String name, String password)
	{
		for(User user:users)
		{
			if(user.getUname().equals(name) && user.getPassword().equals(password))
			{
				return user;
			}
		}
		return null;
	}
}
