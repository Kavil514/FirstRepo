package com.pms.training.exceptions;

public class UserNotFoundException extends Exception {

	public UserNotFoundException(String message)
	{
		super(message);
	}
}
