package com.pms.training.pl;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.Scanner;

import com.pms.training.exceptions.BusinessExceptions;
import com.pms.training.exceptions.UserNotFoundException;
import com.pms.training.pojos.Category;
import com.pms.training.pojos.Product;
import com.pms.training.pojos.User;
import com.pms.training.services.ProductServiceImplementation;
import com.pms.training.services.UserService;
import com.pms.training.services.UserServiceImplementation;

public class ProductApp {
	public static void main(String[] args)
	{
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter number of users:\n");
		int num=sc.nextInt();
		UserService userService=new UserServiceImplementation(num);
		do
		{
			System.out.println("\n1.Login\n2.Signup\n3.Exit\n");
			int choice=sc.nextInt();
			if(choice==1)
			{
				System.out.println("Enter username\t");
				String name=sc.next();
				System.out.println("\nEnter password:\t");;
				String password=sc.next();
				try
				{
					userService.login(name, password);
					System.out.println("Login Success");
					User newUser=userService.getUserByNameAndPass(name,password);
					String userRole=newUser.getRole();
					if(userRole.equalsIgnoreCase("user"))
					{
						Outer1:
						while(true) 
						{
							System.out.println("\nEnter Choice:\n1.Update UserName\n2.Update Password\n3.View Categories\n4.View All Products\n5.View Products By Category\n6.Logout\n");
							choice=sc.nextInt();
							switch(choice)
							{
								case 1:
									System.out.println("\nEnter new User Name");
									newUser.setUname(sc.next());
									System.out.println("User Updated!");
									System.out.println(newUser);
									break;
								case 2:
									System.out.println("\nEnter new Password\n");
									newUser.setPassword(sc.next());
									System.out.println("User Updated!");
									System.out.println(newUser);
									break;
								case 3:
									System.out.println("\nAll Categories:\n________\n");
									try 
									{
										ProductServiceImplementation ps=new ProductServiceImplementation();
										Category[] allCategories=ps.getAllCategories();
										for(Category c:allCategories)
										{
											System.out.println("\n");
											System.out.println(c);
										}
									}catch(BusinessExceptions e)
									{
										System.out.println(e.getMessage());
									}
									break;
								case 4:
									System.out.println("\nAll Products:\n__________\n");
									try {
										ProductServiceImplementation ps=new ProductServiceImplementation();
										Product[] allProducts=ps.getAllProducts();
										for(Product p:allProducts)
										{
											System.out.println("\n");
											System.out.println(p);
										}
									}catch(BusinessExceptions e)
									{
										System.out.println(e.getMessage());
									}
									break;
								case 5:
									System.out.println("\nEnter the category id:\t");
									int catid=sc.nextInt();
									ProductServiceImplementation ps=new ProductServiceImplementation();
									try
									{
										Category[] allCategories=ps.getAllCategories();
										Category curCategory=null;
										for(Category c:allCategories)
										{
											if(c!=null && c.getCatid()==catid)
											{
												curCategory=c;
											}
										}
										try
										{
											Product[] productsByCategory=ps.getAllProductsByCategory(curCategory);
											for(Product p:productsByCategory)
											{
												if(p!=null)
													System.out.println(p);
											}
										}catch(BusinessExceptions e)
										{
											System.out.println(e.getMessage());
										}
									}
									catch(BusinessExceptions e)
									{
										System.out.println(e.getMessage());
									}
									
									break;
								case 6:
									break Outer1;
								default:
									System.out.println("Invalid Input!");
									
							}
							
						}
					}
					else if(userRole.equalsIgnoreCase("admin"))
					{
						Outer:
						while(true) 
						{
							System.out.println("\nEnter Choice:\n1.Add Products\n2.Add Category\n3.View Categories\n4.View All Products\n5.View Products By Category\n6.Logout\n");
							choice=sc.nextInt();
							switch(choice)
							{
								case 1:
									System.out.println("\nAdding Products");
									System.out.println("\n\n Enter the Category ID to which you want to add a product:\t");
									int categoryId=sc.nextInt();
									ProductServiceImplementation ps=new ProductServiceImplementation();
									Category newCategory=new Category();
									//Checking if the category already exists.
									try {
										newCategory=ps.getCategory(categoryId);
									}
									catch(Exception e)
									{
											System.out.println(e.getMessage());
											System.out.println(e.getStackTrace());
											System.out.println("\nCreating New Category.....");
											System.out.println("\nEnter the Category Name");
											String categoryName=sc.next();
											newCategory=new Category(categoryId, categoryName);
											try
											{
												ps.addCategory(newCategory);
											}catch(BusinessExceptions excep)
											{
												
												if(excep.getMessage().equalsIgnoreCase("Category Already Exists!"))
													System.out.println(excep.getMessage());
											}
										
										
									}
									System.out.println("\nEnter Product Details:\n______________\n");
									System.out.println("1.Product ID\n2.Product Name\n3.Product Cost\n4.Product Quantity\n5.Product Brand\n");
									Product newProduct=new Product(sc.nextInt(),sc.next(),sc.nextDouble(),sc.nextInt(),sc.next(),newCategory);
									
									//CHecking if the product with the same Pid already exists.
									try {
										ps.addProduct(newProduct);
									}
									catch(BusinessExceptions e)
									{
										System.out.println(e.getMessage());
									}
									
									break;
								case 2:
									System.out.println("\n\n Enter the Category ID:\t");
									int catId=sc.nextInt();
									ProductServiceImplementation psObj=new ProductServiceImplementation();
									Category category=new Category();
									try {
										category=psObj.getCategory(catId);
									}
									catch(Exception e)
									{
										
											System.out.println(e.getMessage());
											System.out.println("\nCreating New Category.....");
											System.out.println("\nEnter the Category Name");
											String categoryName=sc.next();
											category=new Category(catId, categoryName);
											try
											{
												psObj.addCategory(category);
											}catch(BusinessExceptions excep)
											{
												
												if(excep.getMessage().equalsIgnoreCase("Category Already Exists!"))
													System.out.println(excep.getMessage());
											}
										
										
									}
									break;
								case 3:
									//view all categories
									System.out.println("\nAll Categories:\n__________\n");
									ProductServiceImplementation psObject=new ProductServiceImplementation();
									try
									{
										Category[] allCategories=psObject.getAllCategories();
										for(Category c:allCategories)
										{
											System.out.println("\n");
											System.out.println(c);
										}
												
									}catch(BusinessExceptions e)
									{
										System.out.println(e.getMessage());
									}	
									break;
								case 4:
									//view all products
									System.out.println("\nAll Products:\n____________\n");
									ProductServiceImplementation psObject2=new ProductServiceImplementation();
									try
									{
										Product[] allProducts=psObject2.getAllProducts();
										for(Product p:allProducts)
										{
											System.out.println("\n");
											System.out.println(p);
										}
									}catch(BusinessExceptions e)
									{
										System.out.println(e.getMessage());
									}
									
									break;
								case 5:
									//view product by category
									System.out.println("\nEnter the category id:");
									int catid=sc.nextInt();
									ProductServiceImplementation psObject3=new ProductServiceImplementation();
									Category currentCategory;
									try
									{
										
										currentCategory=psObject3.getCategory(catid);
										Product[] productsByCategory=psObject3.getAllProductsByCategory(currentCategory);
										for(Product p:productsByCategory)
										{
											System.out.println("\n");
											System.out.println(p);
										}
									}catch(BusinessExceptions e)
									{
										System.out.println(e.getMessage());
											
									}
									break;
								case 6:
									break Outer;
								default:
									System.out.println("Invalid Input!");
									
							}
							
						}
					}
					
				}catch(UserNotFoundException u)
				{
					System.out.println(u.getMessage());
				}
				
			}else if(choice==2) {
//				for(int i=0;i<num;i++)
//				{
					System.out.println("\nEnter the User Details\n1.Uname\n2.Password\n3.Role\n4.DOb\n5.Contact Number\n");
					DateTimeFormatter formatter=DateTimeFormatter.ofPattern("dd-MM-yyyy");
					
					User user=new User(sc.next(), sc.next(), sc.next(), LocalDate.parse(sc.next(), formatter) , sc.nextLong());
					try {
						userService.signUp(user);
						User[] users=userService.getAllUsers();
						for(User u:users)
						{
							System.out.println(u);
						}
					}catch(BusinessExceptions e)
					{
						System.out.println(e.getMessage());
					}
//				}
			}else if(choice==3)
			{
				System.out.println("Thank you!");
				sc.close();
				System.exit(0);
			}else
			{
				System.out.println("invalid");
			}
		}while(true);
		
	}
}
