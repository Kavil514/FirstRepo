package com.training.assignment10.service;

import java.time.LocalDate;
import java.util.Comparator;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import com.training.assignment10.pojos.Employee;

public class EmployeeService {

	public double sumOfSalary(List<Employee> employeeList) {
		return employeeList.stream().mapToDouble(i -> i.getSalary()).sum();
	}

	public Map<Object, Integer> departmentNameAndCountEmployees(List<Employee> employeeList) {
		Map<Object, Integer> map = new HashMap<>();
		try {
			Map<Object, List<Employee>> employeeCount = employeeList.stream()
					.collect(Collectors.groupingBy(c -> c.getDeparment().getDepartmentName()));
			for (Object department : employeeCount.keySet()) {
				map.put(department, employeeCount.get(department).size());
			}

		} catch (NullPointerException e) {
			e.printStackTrace();
		}
		return map; // comment the employee list in repo where department is null for the code to work.
	}

	public String seniorMostEmployee(List<Employee> employeeList) {
		LocalDate minDate = employeeList.stream().map(c -> c.getHireDate())
				.min((d1, d2) -> d1.getYear() - (d2.getYear())).get();
		List<Employee> nameList = employeeList.stream().filter(c -> c.getHireDate() == minDate)
				.collect(Collectors.toList());
		Iterator<Employee> itr = nameList.iterator();
		Employee e = new Employee();
		while (itr.hasNext()) {
			e = itr.next();
		}
		return e.getFirstName() + " " + e.getLastName();
	}

	public List<String> employeeDurationOfService(List<Employee> employeeList) {
		List<String> ls = employeeList.stream()
				.map(e -> e.getFirstName() + " " + e.getLastName() + " "
						+ Integer.toString((LocalDate.now().getYear() - e.getHireDate().getYear()) * 12)
						+ e.getHireDate().getMonthValue() + " months and "
						+ Integer.toString(e.getHireDate().getDayOfMonth()) + " days ")
				.collect(Collectors.toList());
		return ls;
	}

	public List<Employee> employeesWithoutDepartment(List<Employee> employeeList) {
		List<Employee> emp = employeeList.stream().filter(e -> e.getDeparment() == null).collect(Collectors.toList());
		return emp;
	}

	public List<Employee> employeesWithoutDepartmentSkip(List<Employee> employeeList) {
		List<Employee> emp = employeeList.stream().filter(e -> e.getDeparment() == null).skip(2)
				.collect(Collectors.toList());
		return emp;
	}

	public String departmentWithHighestEmployees(List<Employee> employeeList) {
		Map<String, Integer> map = new HashMap<>();
		Map.Entry<String, Integer> m1 = null;
		try {
			Map<String, List<Employee>> deptName = employeeList.stream()
					.collect(Collectors.groupingBy(c -> c.getDeparment().getDepartmentName()));
			for (String name : deptName.keySet()) {
				map.put(name, deptName.get(name).size());
			}
		for (Map.Entry<String, Integer> m : map.entrySet()) {
			if (m != null || m.getValue() > m1.getValue())
				m1 = m;
		}
		} catch (NullPointerException e) {
			e.printStackTrace();
		}
		return m1.getKey(); // comment the employee list in repo where department is null for the code to work.
	}

	public List<String> employeeNameHireDateAndDayOfWeek(List<Employee> employeeList) {
		List<String> emp = employeeList.stream()
				.map(c -> c.getFirstName() + " " + c.getHireDate() + " " + c.getHireDate().getDayOfWeek())
				.collect(Collectors.toList());
		return emp;
	}

	public List<String> employeeNameHireDateAndDayOfWeekFriday(List<Employee> employeeList) {
		List<String> emp = employeeList.stream()
				.map(c -> c.getFirstName() + " " + c.getHireDate() + " " + c.getHireDate().getDayOfWeek())
				.collect(Collectors.toList());
		List<String> emp1 = emp.stream().filter(s -> s.contains("FRIDAY")).collect(Collectors.toList());
		return emp1;
	}

	public List<String> employeeNameAndReportingManager(List<Employee> employeeList) {
		List<String> emp = employeeList.stream().map(c -> c.getFirstName() + " reports "
				+ c.getDeparment().getManagerFirstName() + " " + c.getDeparment().getManagerLastName())
				.collect(Collectors.toList());
		return emp;
	}

	public List<String> employeeNameSalaryAndHike(List<Employee> employeeList) {
		List<String> emp = employeeList.stream()
				.map(c -> c.getFirstName() + " " + c.getSalary() + " " + (c.getSalary() + (c.getSalary() * 15 / 100)))
				.collect(Collectors.toList());
		return emp;
	}

	public List<String> employeeNameWithNoManager(List<Employee> employeeList) {
		List<Employee> emp = employeeList.stream().filter(c -> c.getManagerId() == 0).collect(Collectors.toList());
		List<String> emp1 = emp.stream().map(c -> c.getFirstName()).collect(Collectors.toList());
		return emp1;
	}

	public List<String> employeesListFromManagerDetails(String fName, String lName, List<Employee> employeeList) {
		List<String> emp = employeeList.stream()
				.filter(c -> c.getDeparment().getManagerFirstName().equals(fName)
						&& c.getDeparment().getManagerLastName().equals(lName))
				.map(c -> c.getFirstName() + " " + c.getLastName()).collect(Collectors.toList());
		return emp;
	}

	public List<Employee> sortedListByEmployeeId(List<Employee> employeeList) {
		List<Employee> emp = employeeList.stream().sorted(Comparator.comparingInt(Employee::getEmployeeId))
				.collect(Collectors.toList());
		return emp;
	}

	public List<Employee> sortedListByDepartmentId(List<Employee> employeeList) {
		List<Employee> emp = employeeList.stream()
				.sorted(Comparator.comparingInt(e -> e.getDeparment().getDepartmentID())).collect(Collectors.toList());
		return emp;
	}

	public List<String> sortedListByEmployeeName(List<Employee> employeeList) {
		List<String> emp1 = employeeList.stream().map(e -> e.getFirstName()).collect(Collectors.toList());
		List<String> emp = emp1.stream().sorted().collect(Collectors.toList());
		return emp;
	}
}
