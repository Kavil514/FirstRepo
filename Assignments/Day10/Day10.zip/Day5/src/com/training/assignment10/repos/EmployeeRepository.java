package com.training.assignment10.repos;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

import com.training.assignment10.pojos.Department;
import com.training.assignment10.pojos.Employee;

public class EmployeeRepository {

	private static List<Employee> employeeList;
	static {
		employeeList = new ArrayList<>();
		employeeList.add(new Employee(101, "Kavil", "Jain", "asda1@gmail.com", "12334", LocalDate.of(2017, 1, 13),
				"Developer", 20000, 234, new Department(1001, "backend", 234,"Ramesh","Kumar")));
		employeeList.add(new Employee(102, "Lara", "Dutta", "asd3@gmail.com", "123224", LocalDate.of(2018, 5, 21),
				"Developer", 350000, 235, new Department(2001, "frontend", 235,"Suresh","Kumar")));
		employeeList.add(new Employee(103, "Salim", "Khan", "assdda@gmail.com", "167234", LocalDate.of(2019, 8, 8),
				"Manager", 500000, 250, new Department(1001, "backend", 250,"Brijesh","Kumar")));
		employeeList.add(new Employee(104, "Shahid", "Kappor", "asdaaa@gmail.com", "128934", LocalDate.of(2019, 9, 9),
				"HR", 15000, 211, new Department(4001, "technical", 211,"Ketan","Patel")));
		employeeList.add(new Employee(105, "Shanker", "Mahadev", "asd23a@gmail.com", "103234",
				LocalDate.of(2018, 1, 26), "Developer", 15000, 123, new Department(1001, "frontend", 123,"Naman","Mathur")));
//		employeeList.add(new Employee(106, "Shivam", "Mavi", "asd23a@gmail.com", "103234",
//				LocalDate.of(2020, 1, 26), "Developer", 15000, 123, null));
//		employeeList.add(new Employee(107, "Ravi", "Ashwin", "asd23a@gmail.com", "103234",
//				LocalDate.of(2020, 1, 26), "Developer", 15000, 123, null));
//		employeeList.add(new Employee(108, "Yuzi", "Chahal", "asd23a@gmail.com", "103234",
//				LocalDate.of(2020, 1, 26), "Developer", 15000, 0, null));
//		employeeList.add(new Employee(109, "Jasprit", "Bumrah", "asd23a@gmail.com", "103234",
//				LocalDate.of(2020, 1, 26), "Developer", 15000, 0, null));
	}

	public static List<Employee> getEmployeeList() {
		return employeeList;
	}
}
