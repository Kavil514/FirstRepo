package com.training.assignment10.pl;

import java.util.Scanner;

import com.training.assignment10.repos.EmployeeRepository;
import com.training.assignment10.service.EmployeeService;

public class EmployeeApp {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println("Welcome to Employee Application");
//		Department department;
		EmployeeService es = new EmployeeService();
		Scanner sc = new Scanner(System.in);
		do {
			System.out.println(
					"1. Sum of salary of all employees\n2. List out department names and count of employees in each department\n3. Senior most employee of an organization\n4. List employee name and duration of their service in months and days\n5. Find out employees without department\n6. Find out department without employees--skip\n7. Find departments with highest count of employees\n8. List employee name, hire date and day of week on which employee has started\n9. List employee name, hire date and day of week as FRIDAY\n10. List employee�s names and name of manager to whom he/she reports\n11. List employee name, salary and salary increased by 15%\n12. Find employees who didn�t report to anyone\n13. Create a method to accept first name and last name of manager to print name of all his/her subordinates\n14. Sort employees by their EmployeeID\n15. Sort employees by their DepartmentID\n16. Sort employees by their FirstName\n17. Exit");
			switch (sc.nextInt()) {
			case 1:
				System.out.println("Total Salary");
				System.out.println(es.sumOfSalary(EmployeeRepository.getEmployeeList()));
				break;
			case 2:
				System.out.println("Department names and employees count");
				System.out.println(es.departmentNameAndCountEmployees(EmployeeRepository.getEmployeeList()));
				break;
			case 3:
				System.out.println("Senior Most Employee is:");
				System.out.println(es.seniorMostEmployee(EmployeeRepository.getEmployeeList()));
				break;
			case 4:
				System.out.println("Employess with months and days of service");
				System.out.println(es.employeeDurationOfService(EmployeeRepository.getEmployeeList()));
				break;
			case 5:
				System.out.println("Employees without department");
				System.out.println(es.employeesWithoutDepartment(EmployeeRepository.getEmployeeList()));
				break;
			case 6:
				System.out.println("Employees without department after skipping 2 records");
				System.out.println(es.employeesWithoutDepartmentSkip(EmployeeRepository.getEmployeeList()));
				break;
			case 7:
				System.out.println("Departments with highest count of employees");
				System.out.println(es.departmentWithHighestEmployees(EmployeeRepository.getEmployeeList()));
				break;
			case 8:
				System.out.println("Employee name, hire date and day of week");
				System.out.println(es.employeeNameHireDateAndDayOfWeek(EmployeeRepository.getEmployeeList()));
				break;
			case 9:
				System.out.println("Employee name, hire date and day of week is friday");
				System.out.println(es.employeeNameHireDateAndDayOfWeekFriday(EmployeeRepository.getEmployeeList()));
				break;
			case 10:
				System.out.println("Employee name reports to manager");
				System.out.println(es.employeeNameAndReportingManager(EmployeeRepository.getEmployeeList()));
				break;
			case 11:
				System.out.println("Employee name, salary and salary increased by 15%");
				System.out.println(es.employeeNameSalaryAndHike(EmployeeRepository.getEmployeeList()));
				break;
			case 12:
				System.out.println("Employee with no manager");
				System.out.println(es.employeeNameWithNoManager(EmployeeRepository.getEmployeeList()));
				break;
			case 13:
				System.out.println("Get Employees by First and Last Name of Manager");
				System.out.println("Enter First Last Name of Manager");
				System.out.println(es.employeesListFromManagerDetails(sc.next(), sc.next(), EmployeeRepository.getEmployeeList()));
				break;
			case 14:
				System.out.println("Sorted List:");
				System.out.println(es.sortedListByEmployeeId(EmployeeRepository.getEmployeeList()));
				break;
			case 15:
				System.out.println("Sorted List:");
				System.out.println(es.sortedListByDepartmentId(EmployeeRepository.getEmployeeList()));
				break;
			case 16:
				System.out.println("Sorted List:");
				System.out.println(es.sortedListByEmployeeName(EmployeeRepository.getEmployeeList()));
				break;
			case 17:
				System.out.println("Thank You");
				System.exit(0);
				sc.close();
				break;
			default:
				System.out.println("Invalid Input");
			}
		} while (true);
	}

}
