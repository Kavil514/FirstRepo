package com.training.assignment10.pojos;

public class Department {
	private int departmentID;
	private String departmentName;
	private int managerId;
	private String managerFirstName;
	private String managerLastName;

	public Department(String managerFirstName, String managerLastName) {
		super();
		this.managerFirstName = managerFirstName;
		this.managerLastName = managerLastName;
	}

	public Department(int departmentID, String departmentName, int managerId, String managerFirstName,
			String managerLastName) {
		this.departmentID = departmentID;
		this.departmentName = departmentName;
		this.managerId = managerId;
		this.managerFirstName = managerFirstName;
		this.managerLastName = managerLastName;
	}

	public int getDepartmentID() {
		return departmentID;
	}

	public void setDepartmentID(int departmentID) {
		this.departmentID = departmentID;
	}

	public String getDepartmentName() {
		return departmentName;
	}

	public void setDepartmentName(String departmentName) {
		this.departmentName = departmentName;
	}

	public int getManagerId() {
		return managerId;
	}

	public void setManagerId(int managerId) {
		this.managerId = managerId;
	}

	public String getManagerFirstName() {
		return managerFirstName;
	}

	public void setManagerFirstName(String managerFirstName) {
		this.managerFirstName = managerFirstName;
	}

	public String getManagerLastName() {
		return managerLastName;
	}

	public void setManagerLastName(String managerLastName) {
		this.managerLastName = managerLastName;
	}

	@Override
	public String toString() {
		return "Department [departmentID=" + departmentID + ", departmentName=" + departmentName + ", managerId="
				+ managerId + ", managerFirstName=" + managerFirstName + ", managerLastName=" + managerLastName + "]";
	}

}
