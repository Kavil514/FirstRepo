package com.infrrd.training.bo;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.infrrd.training.entities.Library;
import com.infrrd.training.entities.Student;
import com.infrrd.training.repos.LibraryRepo;
import com.infrrd.training.repos.StudentRepo;

@Service
public class LibraryBoImpl implements LibraryBo {

	@Autowired
	LibraryRepo libraryRepo;
	@Autowired
	StudentRepo studentRepo;

	@Override
	public List<Library> getAll() {
		return (List<Library>) libraryRepo.findAll();
	}

	@Override
	@Transactional
	public boolean addBooks(Library library) {
		return libraryRepo.save(library) != null;
	}

	@Override
	@Transactional
	public void removeBooks(int bid) {
		libraryRepo.delete(bid);
	}

	@Override
	public List<Library> getByBname(String bname) {
		return libraryRepo.findByBname(bname);
	}

	@Override
	public Library getByBid(int Bid) {
		return libraryRepo.findByBid(Bid);
	}

	@Override
	public List<Library> getByPrice(double price) {
		return (List<Library>) libraryRepo.findByPrice(price);
	}

	@Override
	@Transactional
	public int editLibraryBookPrices(double price, int bid) {
		return libraryRepo.updateLibraryBookPrices(price, bid);
	}

	@Override
	public List<Library> getByBnameIgnoreCase(String bname) {
		return libraryRepo.findByBnameIgnoreCase(bname);
	}

	@Override
	public List<Library> getByBnameLike(String bname) {
		return libraryRepo.findByBnameLike(bname);
	}

	@Override
	public List<Library> getByBnameNotLike(String bname) {
		return libraryRepo.findByBnameNotLike(bname);
	}

	@Override
	public List<Library> getByBnameStartingWith(String bname) {
		return libraryRepo.findByBnameStartingWith(bname);
	}

	@Override
	public List<Library> getByBnameEndingWith(String bname) {
		return libraryRepo.findByBnameEndingWith(bname);
	}

	@Override
	public List<Library> getByBnameContaining(String bname) {
		return libraryRepo.findByBnameContaining(bname);
	}

	@Override
	public List<Library> getByBnameIgnoreCaseContaining(String bname) {
		return libraryRepo.findByBnameIgnoreCase(bname);
	}

	@Override
	public List<Library> getByPriceOrderByBnameDesc(double price) {
		return libraryRepo.findByPriceOrderByBnameDesc(price);
	}
	
	@Override
	public List<Library> getByPriceGreaterThan(double price) {
		return libraryRepo.findByPriceGreaterThan(price);
	}

	@Override
	public List<Library> getByPriceLessThan(double price) {
		return libraryRepo.findByPriceLessThan(price);
	}

	@Override
	@Transactional
	public boolean addStudent(Student student) {
		return studentRepo.save(student) != null;
	}

	@Override
	@Transactional
	public void removeStudent(int sid) {
		studentRepo.delete(sid);
	}

	@Override
	public List<Student> getAllStudents() {
		return studentRepo.findAll();
	}

	@Override
	public List<Student> getBySname(String sname) {
		return studentRepo.findBySname(sname);
	}

	@Override
	public Student getBySid(int sid) {
		return studentRepo.findBySid(sid);
	}

	@Override
	public List<Student> getByAge(int age) {
		return (List<Student>) studentRepo.findByAge(age);
	}

	@Override
	@Transactional
	public int editStudentNameById(String sname, int sid) {
		return studentRepo.updateStudentNameById(sname, sid);
	}

	@Override
	public List<Student> getBySnameIgnoreCase(String sname) {
		return studentRepo.findBySnameIgnoreCase(sname);
	}

	@Override
	public List<Student> getBySnameLike(String sname) {
		return studentRepo.findBySnameLike(sname);
	}

	@Override
	public List<Student> getBySnameNotLike(String sname) {
		return studentRepo.findBySnameNotLike(sname);
	}

	@Override
	public List<Student> getBySnameStartingWith(String sname) {
		return studentRepo.findBySnameStartingWith(sname);
	}

	@Override
	public List<Student> getBySnameEndingWith(String sname) {
		return studentRepo.findBySnameEndingWith(sname);
	}

	@Override
	public List<Student> getBySnameContaining(String sname) {
		return studentRepo.findBySnameContaining(sname);
	}

	@Override
	public List<Student> getBySnameIgnoreCaseContaining(String sname) {
		return studentRepo.findBySnameIgnoreCaseContaining(sname);
	}

	@Override
	public List<Student> getByAgeOrderBySnameDesc(int age) {
		return studentRepo.findByAgeOrderBySnameDesc(age);
	}

	@Override
	public List<Student> getByAgeGreaterThan(int age) {
		return studentRepo.findByAgeGreaterThan(age);
	}

	@Override
	public List<Student> getByAgeLessThan(int age) {
		return studentRepo.findByAgeLessThan(age);
	}

}
