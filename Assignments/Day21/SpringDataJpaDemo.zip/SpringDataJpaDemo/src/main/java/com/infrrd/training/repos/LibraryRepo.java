package com.infrrd.training.repos;

import java.util.List;

import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.infrrd.training.entities.Library;

@Repository
public interface LibraryRepo extends CrudRepository<Library, Integer> {

	@Query(value = "select l from Library l")
	public List<Library> findAll();

	public List<Library> findByBname(String bname);

	public Library findByBid(int Bid);

	public List<Library> findByPrice(double price);

	@Modifying
	@Query(value = "update library set price = ?1 where bid = ?2", nativeQuery = true)
	public int updateLibraryBookPrices(double price, int bid);

	public List<Library> findByBnameIgnoreCase(String bname);

	@Query(value = "select * from library where bname like '?1'", nativeQuery = true)
	public List<Library> findByBnameLike(String bname);

	@Query(value = "select * from library where bname not like '?1'", nativeQuery = true)
	public List<Library> findByBnameNotLike(String bname);

	@Query(value = "select * from library where bname like '?1%'", nativeQuery = true)
	public List<Library> findByBnameStartingWith(String bname);

	@Query(value = "select * from library where bname like '%?1'", nativeQuery = true)
	public List<Library> findByBnameEndingWith(String bname);

	public List<Library> findByBnameContaining(String bname);

	public List<Library> findByBnameIgnoreCaseContaining(String bname);

	public List<Library> findByPriceOrderByBnameDesc(double price);

	public List<Library> findByPriceGreaterThan(double price);

	public List<Library> findByPriceLessThan(double price);
}
