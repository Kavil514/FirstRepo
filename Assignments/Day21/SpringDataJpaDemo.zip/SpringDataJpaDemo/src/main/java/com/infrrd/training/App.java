package com.infrrd.training;

import java.util.Scanner;

import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;
import org.springframework.context.support.AbstractApplicationContext;

import com.infrrd.training.bo.LibraryBo;
import com.infrrd.training.config.AppConfiig;
import com.infrrd.training.entities.Library;
import com.infrrd.training.entities.Student;

/**
 * Hello world!
 *
 */
public class App {
	public static void main(String[] args) {
		ApplicationContext context = new AnnotationConfigApplicationContext(AppConfiig.class);
		LibraryBo libraryBo = context.getBean(LibraryBo.class);
		Library library = new Library();
		Student student = new Student();
		Scanner sc = new Scanner(System.in);
		do {
			System.out.println(
					"\n1. Get All Books\n2. Add Books\n3. Edit Book's Price\n4. Delete Books\n5. Get Books by Book Id\n6. Get Books by Name"
							+ "\n7. Get Books by Price\n8. Get Books Name(Ignore Case)\n9. Get Books Name(Like)\n10. Get Books Name(Not Like)"
							+ "\n11. Get Book Name(Starting With)\n12. Get Book Name(Ending With)\n13. Get Book Name(Containing)\n14. Get Book Name(Containing IGC)"
							+ "\n15. Get Price In descending order of Name\n16. Get Price Greater Than\n17. Get Price Lesser Than"
							+ "\n18. Get All Students\n19. Add Student\n20. Edit Students's Name\n21. Delete Student\n22. Get Student by Student Id"
							+ "\n23. Get Students by Name\n24. Get Students by Age\n25. Get Student Name(Ignore Case)\n26. Get Student Name(Like)"
							+ "\n27. Get Student Name(Not Like)\n28. Get Student Name(Starting With)\n29. Get Student Name(Ending With)\n30. Get Student Name"
							+ "(Containing)\n31. Get Student Name(Containing IGC)\n32. Get Age In descending order of Name\n33. Get Age Greater Than\n34"
							+ ". Get Price Lesser Than\n35. Exit");
			switch (sc.nextInt()) {
			case 1:
				System.out.println(libraryBo.getAll());
				break;
			case 2:
				System.out.println("Enter book id");
				library.setBid(sc.nextInt());
				System.out.println("Enter book name");
				library.setBname(sc.next());
				System.out.println("Enter price");
				library.setPrice(sc.nextDouble());
				libraryBo.addBooks(library);
				System.out.println("Book added!!");
				break;
			case 3:
				System.out.println("Enter the Id");
				int bid = sc.nextInt();
				System.out.println("enter price");
				double price = sc.nextDouble();
				int i = libraryBo.editLibraryBookPrices(price, bid);
				if (i != 0)
					System.out.println("Updated");
				else 
					System.out.println("Error in updating");
				break;
			case 4:
				System.out.println("Enter book id");
				libraryBo.removeBooks(sc.nextInt());
				break;
			case 5:
				System.out.println("Enter Book Id");
				System.out.println(libraryBo.getByBid(sc.nextInt()));
				break;
			case 6:
				System.out.println("Enter Book Name");
				System.out.println(libraryBo.getByBname(sc.next()));
				break;
			case 7:
				System.out.println("Enter Book Id");
				System.out.println(libraryBo.getByPrice(sc.nextDouble()));
				break;
			case 8:
				System.out.println("Enter Book Name (Case insensitive)");
				System.out.println(libraryBo.getByBnameIgnoreCase(sc.next()));
				break;
			case 9:
				System.out.println("Search book by any character");
				System.out.println(libraryBo.getByBnameLike(sc.next()));
				break;
			case 10:
				System.out.println("Search books not like");
				System.out.println(libraryBo.getByBnameNotLike(sc.next()));
				break;
			case 11:
				System.out.println("Search books starting with");
				System.out.println(libraryBo.getByBnameStartingWith(sc.next()));
				break;
			case 12:
				System.out.println("Search books ending with");
				System.out.println(libraryBo.getByBnameEndingWith(sc.next()));
				break;
			case 13:
				System.out.println("Search books containing");
				System.out.println(libraryBo.getByBnameContaining(sc.next()));
				break;
			case 14:
				System.out.println("Search books not containing ignore case");
				System.out.println(libraryBo.getByBnameIgnoreCaseContaining(sc.next()));
				break;
			case 15:
				System.out.println(libraryBo.getByPriceOrderByBnameDesc(sc.nextDouble()));
				break;
			case 16:
				System.out.println("Enter price");
				System.out.println(libraryBo.getByPriceGreaterThan(sc.nextDouble()));
				break;
			case 17:
				System.out.println("Enter price");
				System.out.println(libraryBo.getByPriceLessThan(sc.nextDouble()));
				break;
			case 18:
				System.out.println(libraryBo.getAllStudents());
				break;
			case 19:
				System.out.println("Enter student id");
				student.setSid(sc.nextInt());
				System.out.println("Enter student name");
				student.setSname(sc.next());
				System.out.println("Enter age");
				student.setAge(sc.nextInt());
				libraryBo.addStudent(student);
				System.out.println("Student added!!");
				break;
			case 20:
				System.out.println("Enter the Id");
				int sid = sc.nextInt();
				System.out.println("enter Name");
				String sname = sc.next();
				int j = libraryBo.editStudentNameById(sname, sid);
				if (j != 0)
					System.out.println("Updated");
				else 
					System.out.println("Error in updating");
				break;
			case 21:
				System.out.println("Enter student id");
				libraryBo.removeStudent(sc.nextInt());
				break;
			case 22:
				System.out.println("Enter student id");
				System.out.println(libraryBo.getBySid(sc.nextInt()));
				break;
			case 23:
				System.out.println("Enter student name");
				System.out.println(libraryBo.getBySname(sc.next()));
				break;
			case 24:
				System.out.println("Enter student age");
				System.out.println(libraryBo.getByAge(sc.nextInt()));
				break;
			case 25:
				System.out.println("Enter student name (case insensitive)");
				System.out.println(libraryBo.getBySnameIgnoreCase(sc.next()));
				break;
			case 26:
				System.out.println("Enter student name like");
				System.out.println(libraryBo.getBySnameLike(sc.next()));
				break;
			case 27:
				System.out.println("Enter student name not like");
				System.out.println(libraryBo.getBySnameNotLike(sc.next()));
				break;
			case 28:
				System.out.println("Enter student name starting with");
				System.out.println(libraryBo.getBySnameStartingWith(sc.next()));
				break;
			case 29:
				System.out.println("Enter student name ending with");
				System.out.println(libraryBo.getBySnameEndingWith(sc.next()));
				break;
			case 30:
				System.out.println("Enter student name containing");
				System.out.println(libraryBo.getBySnameContaining(sc.next()));
				break;
			case 31:
				System.out.println("Enter student name containing Ignore case");
				System.out.println(libraryBo.getBySnameIgnoreCaseContaining(sc.next()));
				break;
			case 32:
				System.out.println("Enter age");
				System.out.println(libraryBo.getByAgeOrderBySnameDesc(sc.nextInt()));
				break;
			case 33:
				System.out.println("Enter age");
				System.out.println(libraryBo.getByAgeGreaterThan(sc.nextInt()));
				break;
			case 34:
				System.out.println("Enter age");
				System.out.println(libraryBo.getByAgeLessThan(sc.nextInt()));
				break;
			case 35:
				System.out.println("Thank you");
				sc.close();
				System.exit(0);
				((AbstractApplicationContext) context).close();
			}
		} while (true);

	}
}
