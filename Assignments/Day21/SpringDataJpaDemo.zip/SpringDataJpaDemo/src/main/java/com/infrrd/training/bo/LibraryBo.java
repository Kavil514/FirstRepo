package com.infrrd.training.bo;

import java.util.List;

import com.infrrd.training.entities.Library;
import com.infrrd.training.entities.Student;

public interface LibraryBo {
	public boolean addBooks(Library library);

	public void removeBooks(int bid);

	public List<Library> getAll();

	public List<Library> getByBname(String bname);

	public Library getByBid(int Bid);

	public List<Library> getByPrice(double price);

	public int editLibraryBookPrices(double price, int bid);

	public List<Library> getByBnameIgnoreCase(String bname);

	public List<Library> getByBnameLike(String bname);

	public List<Library> getByBnameNotLike(String bname);

	public List<Library> getByBnameStartingWith(String bname);

	public List<Library> getByBnameEndingWith(String bname);

	public List<Library> getByBnameContaining(String bname);

	public List<Library> getByBnameIgnoreCaseContaining(String bname);

	public List<Library> getByPriceOrderByBnameDesc(double price);

	public List<Library> getByPriceGreaterThan(double price);

	public List<Library> getByPriceLessThan(double price);

	public boolean addStudent(Student student);

	public void removeStudent(int sid);

	public List<Student> getAllStudents();

	public List<Student> getBySname(String sname);

	public Student getBySid(int sid);

	public List<Student> getByAge(int age);

	public int editStudentNameById(String sname, int sid);

	public List<Student> getBySnameIgnoreCase(String sname);

	public List<Student> getBySnameLike(String sname);

	public List<Student> getBySnameNotLike(String sname);

	public List<Student> getBySnameStartingWith(String sname);

	public List<Student> getBySnameEndingWith(String sname);

	public List<Student> getBySnameContaining(String sname);

	public List<Student> getBySnameIgnoreCaseContaining(String sname);

	public List<Student> getByAgeOrderBySnameDesc(int age);

	public List<Student> getByAgeGreaterThan(int age);

	public List<Student> getByAgeLessThan(int age);

}
