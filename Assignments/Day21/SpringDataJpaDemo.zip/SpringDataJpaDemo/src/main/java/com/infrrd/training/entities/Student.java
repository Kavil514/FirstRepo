package com.infrrd.training.entities;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToMany;

@Entity
public class Student {
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private int sid;
	@Column(length = 20)
	private String sname;
	private int age;
	@ManyToMany(cascade = CascadeType.ALL,fetch = FetchType.EAGER)
	private List<Library> library = new ArrayList<Library>();

	public Student() {
		// TODO Auto-generated constructor stub
	}

	public Student(int sid, String sname, int age, List<Library> library) {
		super();
		this.sid = sid;
		this.sname = sname;
		this.age = age;
		this.library = library;
	}

	public int getSid() {
		return sid;
	}

	public void setSid(int sid) {
		this.sid = sid;
	}

	public String getSname() {
		return sname;
	}

	public void setSname(String sname) {
		this.sname = sname;
	}

	public int getAge() {
		return age;
	}

	public void setAge(int age) {
		this.age = age;
	}

	public List<Library> getLibrary() {
		return library;
	}

	public void setLibrary(List<Library> library) {
		this.library = library;
	}

	@Override
	public String toString() {
		return "Student [sid=" + sid + ", sname=" + sname + ",age=" + age + "]";
	}

}
