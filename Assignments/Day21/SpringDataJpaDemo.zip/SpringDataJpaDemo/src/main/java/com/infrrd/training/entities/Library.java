package com.infrrd.training.entities;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToMany;

@Entity
public class Library {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int bid;
	@Column(length = 20)
	private String bname;
	@Column(columnDefinition = "decimal(6,2)")
	private double price;
	@ManyToMany(cascade = CascadeType.ALL, fetch = FetchType.EAGER)
	private List<Student> students = new ArrayList<Student>();

	public Library() {
		// TODO Auto-generated constructor stub
	}

	public Library(int bid, String bname, double price, List<Student> students) {
		super();
		this.bid = bid;
		this.bname = bname;
		this.price = price;
		this.students = students;
	}

	public int getBid() {
		return bid;
	}

	public void setBid(int bid) {
		this.bid = bid;
	}

	public String getBname() {
		return bname;
	}

	public void setBname(String bname) {
		this.bname = bname;
	}

	public double getPrice() {
		return price;
	}

	public void setPrice(double price) {
		this.price = price;
	}

	public List<Student> getStudents() {
		return students;
	}

	public void setStudents(List<Student> students) {
		this.students = students;
	}

	@Override
	public String toString() {
		return "Library [bid=" + bid + ", bname=" + bname + ", price=" + price +"]";
	}

}
