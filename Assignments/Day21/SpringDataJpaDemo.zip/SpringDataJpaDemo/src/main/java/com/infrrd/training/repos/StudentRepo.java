package com.infrrd.training.repos;

import java.util.List;

import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.infrrd.training.entities.Student;

@Repository
public interface StudentRepo extends CrudRepository<Student, Integer> {

	@Query(value = "select l from Student l")
	public List<Student> findAll();

	public List<Student> findBySname(String sname);

	public Student findBySid(int sid);

	public List<Student> findByAge(int age);

	@Modifying
	@Query(value = "update student set sname = ?1 where sid = ?2", nativeQuery = true)
	public int updateStudentNameById(String sname, int sid);

	public List<Student> findBySnameIgnoreCase(String sname);

	@Query(value = "select * from student where sname like '?1'", nativeQuery = true)
	public List<Student> findBySnameLike(String sname);

	@Query(value = "select * from student where sname not like '?1'", nativeQuery = true)
	public List<Student> findBySnameNotLike(String sname);

	@Query(value = "select * from student where sname like '?1%'", nativeQuery = true)
	public List<Student> findBySnameStartingWith(String sname);

	@Query(value = "select * from student where sname like '?1%'", nativeQuery = true)
	public List<Student> findBySnameEndingWith(String sname);

	public List<Student> findBySnameContaining(String sname);

	public List<Student> findBySnameIgnoreCaseContaining(String sname);

	public List<Student> findByAgeOrderBySnameDesc(int age);

	public List<Student> findByAgeGreaterThan(int age);

	public List<Student> findByAgeLessThan(int age);
}
