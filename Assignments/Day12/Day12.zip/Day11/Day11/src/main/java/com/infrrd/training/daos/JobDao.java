package com.infrrd.training.daos;

import java.util.List;

import com.infrrd.training.pojos.Job;

public interface JobDao {
	public List<Job> retriveAll();

	public int insertJob(Job j);

	public int updateJob(String jCode, String jName);

	public int deleteJob(String jCode);

	public Job retriveJobById(String jCode);
}
