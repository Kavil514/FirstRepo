package com.infrrd.training;

/**
 * Hello world!
 *
 */
import java.sql.*;

public class App {
	public static void main(String[] args) throws ClassNotFoundException {
		//Class.forName("com.mysql.cj.jdbc.Driver");// optional
		try {
			Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/infrrd", "root", "Kavil@514");
			System.out.println("Connected");
			Statement st = conn.createStatement();
			int i = st.executeUpdate("insert into job values('J007','Research')");
			if(i>0) {
				System.out.println("Inserted");
			}
			else {
				System.out.println("Problem");
			}
			ResultSet rs = st.executeQuery("select * from job");
			while (rs.next()) {
				System.out.println(rs.getString(1) + " " + rs.getString(2));
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
}
