package com.infrrd.training.daos;

import java.util.List;

import com.infrrd.training.pojos.Department;

public interface DepartmentDao {
	public List<Department> retriveAll();

	public int insertDepartment(Department d);

	public int updateDepartmentLocation(int lCode, int deptNo);

	public int deleteDepartment(int deptNo);

	public Department retriveDepartmentById(int deptNo);
}
