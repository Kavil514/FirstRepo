package com.infrrd.training.services;

import java.util.List;

import com.infrrd.training.exceptions.BusinessException;
import com.infrrd.training.exceptions.RecordNotFoundException;
import com.infrrd.training.pojos.Department;
import com.infrrd.training.pojos.Employee;
import com.infrrd.training.pojos.Job;
import com.infrrd.training.pojos.Location;

public interface EmployeeService {
	public List<Employee> getAll() throws BusinessException;

	public int addEmployee(Employee e) throws BusinessException;

	public int editEmployeeSalary(double salary, int eId) throws BusinessException;

	public int editEmployeeJob(String jCode, int eId) throws BusinessException;

	public int editEmployeeDepartment(int dCode, int eId) throws BusinessException;

	public int removeEmployee(int eId) throws RecordNotFoundException;

	public Employee getEmployeeById(int eId) throws RecordNotFoundException;

	public List<Employee> getEmployeeByJName(String jName) throws BusinessException;
	
	public List<String> getEmployeeNames() throws BusinessException;
	
	public List<Employee> getSortedEmployeeBasedOnSalary() throws BusinessException;
	
	public List<Employee> getSortedEmployeeBasedOnDoj() throws BusinessException;
	

	public List<Department> getAllDepartment() throws BusinessException;

	public int addDepartment(Department d) throws BusinessException;

	public int editDepartmentLocation(int lCode, int deptNo) throws BusinessException;

	public int removeDepartment(int deptNo) throws BusinessException;

	public Department getDepartmentById(int deptNo) throws BusinessException;

	
	public List<Location> getAllLocation() throws BusinessException;

	public int addLocation(Location l) throws BusinessException;

	public int editLocation(int lCode, String lName) throws BusinessException;

	public int removeLocation(int lCode) throws BusinessException;

	public Location getLocationById(int lCode) throws BusinessException;

	
	public List<Job> getAllJob() throws BusinessException;

	public int addJob(Job j) throws BusinessException;

	public int editJob(String jCode, String jName)throws BusinessException;

	public int removeJob(String jCode) throws BusinessException;

	public Job getJobById(String jCode) throws BusinessException;
}
