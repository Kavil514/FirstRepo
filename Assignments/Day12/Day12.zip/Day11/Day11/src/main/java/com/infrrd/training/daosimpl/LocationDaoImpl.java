package com.infrrd.training.daosimpl;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import com.infrrd.training.daos.LocationDao;
import com.infrrd.training.pojos.Location;
import com.infrrd.training.util.DbUtil;

public class LocationDaoImpl implements LocationDao {

	private Connection con = null;

	public LocationDaoImpl() {
		con = DbUtil.openConnection();
	}

	public List<Location> retriveAll() {
		List<Location> location = new ArrayList<Location>();
		try {
			Statement st = con.createStatement();
			ResultSet rs = st.executeQuery("select * from location");
			while (rs.next()) {
				Location l = new Location();
				l.setLcode(rs.getInt("lcode"));
				l.setLname(rs.getString("lname"));
				location.add(l);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return location;
	}

	public int insertLocation(Location l) {
		int i = 0;
		try {
			String sql = "insert into location values(?,?)";
			PreparedStatement pst = con.prepareStatement(sql);
			pst.setInt(1, l.getLcode());
			pst.setString(2, l.getLname());
			i = pst.executeUpdate();
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return i;
	}

	public int updateLocation(int lCode, String lName) {
		int i = 0;
		try {
			String sql = "update location set lname=? where lcode=? ";
			PreparedStatement pst = con.prepareStatement(sql);
			pst.setString(1, lName);
			pst.setInt(2, lCode);
			i = pst.executeUpdate();
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return i;
	}

	public int deleteLocation(int lCode) {
		int i = 0;
		try {
			String sql = "delete from location where lcode=?";
			PreparedStatement pst = con.prepareStatement(sql);
			pst.setInt(1, lCode);
			i = pst.executeUpdate();
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return i;
	}

	public Location retriveLocationById(int lCode) {
		Location l = new Location();
		try {
			String sql = "select * from location where lcode = ?";
			PreparedStatement pst = con.prepareStatement(sql);
			pst.setInt(1, lCode);
			ResultSet rs = pst.executeQuery();
			while (rs.next()) {
				l.setLcode(rs.getInt("lcode"));
				l.setLname(rs.getString("lname"));
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return l;
	}

}
