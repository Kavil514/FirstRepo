package com.infrrd.training.daos;

import java.util.List;

import com.infrrd.training.pojos.Employee;

public interface EmployeeDao {
	public List<Employee> retriveAll();

	public int insertEmployee(Employee e);

	public int updateEmployeeSalary(double salary, int eId);

	public int updateEmployeeJob(String jCode, int eId);

	public int updateEmployeeDepartment(int dCode, int eId);

	public int deleteEmployee(int eId);

	public Employee retriveEmployeeById(int eId);

	public List<Employee> retriveEmployeeByJName(String jName);
}
