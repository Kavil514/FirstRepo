package com.infrrd.training.util;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class DbUtil {
	private static Connection con = null;
	//to restrict not to create the object for this class --- singleton
	private DbUtil() {

	}

	public static Connection openConnection() {
		try {
			con = DriverManager.getConnection("jdbc:mysql://localhost:3306/infrrd", "root", "Kavil@514");
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return con;
	}

	public static void closeConnection() {
		try {
			con.close();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
}
