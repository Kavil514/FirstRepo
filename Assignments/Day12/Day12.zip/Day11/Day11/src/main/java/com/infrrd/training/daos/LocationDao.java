package com.infrrd.training.daos;

import java.util.List;

import com.infrrd.training.pojos.Location;

public interface LocationDao {
	public List<Location> retriveAll();

	public int insertLocation(Location l);

	public int updateLocation(int lCode, String lName);

	public int deleteLocation(int lCode);

	public Location retriveLocationById(int lCode);
}
