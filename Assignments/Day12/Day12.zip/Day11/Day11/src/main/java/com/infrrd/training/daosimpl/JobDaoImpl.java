package com.infrrd.training.daosimpl;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import com.infrrd.training.daos.JobDao;
import com.infrrd.training.pojos.Job;
import com.infrrd.training.util.DbUtil;

public class JobDaoImpl implements JobDao {

	private Connection con = null;

	public JobDaoImpl() {
		con = DbUtil.openConnection();
	}

	public List<Job> retriveAll() {
		List<Job> job = new ArrayList<Job>();
		try {
			Statement st = con.createStatement();
			ResultSet rs = st.executeQuery("select * from job");
			while (rs.next()) {
				Job j = new Job();
				j.setJcode(rs.getString("jcode"));
				j.setJname(rs.getString("jname"));
				job.add(j);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return job;
	}

	public int insertJob(Job j) {
		int i = 0;
		try {
			String sql = "insert into job values(?,?)";
			PreparedStatement pst = con.prepareStatement(sql);
			pst.setString(1, j.getJcode());
			pst.setString(2, j.getJname());
			i = pst.executeUpdate();
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return i;
	}

	public int updateJob(String jCode, String jName) {
		int i = 0;
		try {
			String sql = "update job set jname=? where jcode=? ";
			PreparedStatement pst = con.prepareStatement(sql);
			pst.setString(1, jName);
			pst.setString(2, jCode);
			i = pst.executeUpdate();
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return i;
	}

	public int deleteJob(String jCode) {
		int i = 0;
		try {
			String sql = "delete from job where jcode=?";
			PreparedStatement pst = con.prepareStatement(sql);
			pst.setString(1, jCode);
			i = pst.executeUpdate();
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return i;
	}

	public Job retriveJobById(String jCode) {
		Job j = new Job();
		try {
			String sql = "select * from job where jcode = ?";
			PreparedStatement pst = con.prepareStatement(sql);
			pst.setString(1, jCode);
			ResultSet rs = pst.executeQuery();
			while (rs.next()) {
				j.setJcode(rs.getString("jcode"));
				j.setJname(rs.getString("jname"));
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return j;
	}

}
