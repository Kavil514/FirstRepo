package com.infrrd.training.daosimpl;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

import com.infrrd.training.daos.EmployeeDao;
import com.infrrd.training.pojos.Employee;
import com.infrrd.training.util.DbUtil;

public class EmployeeDaoImpl implements EmployeeDao {

	private Connection con = null;

	public EmployeeDaoImpl() {
		con = DbUtil.openConnection();
	}

	public List<Employee> retriveAll() {
		List<Employee> employees = new ArrayList<Employee>();
		try {
			Statement st = con.createStatement();
			ResultSet rs = st.executeQuery("select * from employee");
			while (rs.next()) {
				Employee e = new Employee();
				e.setEid(rs.getInt("eid"));
				e.setEname(rs.getString("ename"));
				e.setSalary(rs.getDouble("salary"));
				e.setBonus(rs.getInt("bonus"));
				e.setMgrNo(rs.getInt("mgrno"));
				e.setJcode(rs.getString("jcode"));
				e.setDeptNo(rs.getInt("deptno"));
				java.sql.Date sqlDate = rs.getDate("doj");
				LocalDate ld = sqlDate.toLocalDate();
				e.setDoj(ld);
				employees.add(e);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return employees;
	}

	public int insertEmployee(Employee e) {
		int i = 0;
		try {
			String sql = "insert into employee values(?,?,?,?,?,?,?,?)";
			PreparedStatement pst = con.prepareStatement(sql);
			pst.setInt(1, e.getEid());
			pst.setString(2, e.getEname());
			pst.setDouble(3, e.getSalary());
			pst.setInt(4, e.getBonus());
			pst.setInt(5, e.getMgrNo());
			pst.setString(6, e.getJcode());
			pst.setInt(7, e.getDeptNo());
			LocalDate ld = e.getDoj();
			pst.setDate(8, java.sql.Date.valueOf(ld));
			i = pst.executeUpdate();
		} catch (SQLException e1) {
			e1.printStackTrace();
		}
		return i;
	}

	public int updateEmployeeSalary(double salary, int eid) {
		int i = 0;
		try {
			String sql = "update employee set salary=? where eid=? ";
			PreparedStatement pst = con.prepareStatement(sql);
			pst.setDouble(1, salary);
			pst.setInt(2, eid);
			i = pst.executeUpdate();
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return i;
	}

	public int updateEmployeeJob(String jcode, int eid) {
		int i = 0;
		try {
			String sql = "update employee set jcode=? where eid=?";
			PreparedStatement pst = con.prepareStatement(sql);
			pst.setString(1, jcode);
			pst.setInt(2, eid);
			i = pst.executeUpdate();
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return i;
	}

	public int updateEmployeeDepartment(int dCode, int eid) {
		int i = 0;
		try {
			String sql = "update employee set deptno=? where eid=?";
			PreparedStatement pst = con.prepareStatement(sql);
			pst.setInt(1, dCode);
			pst.setInt(2, eid);
			i = pst.executeUpdate();
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return i;
	}

	public int deleteEmployee(int eid) {
		int i = 0;
		try {
			String sql = "delete from employee where eid=?";
			PreparedStatement pst = con.prepareStatement(sql);
			pst.setInt(1, eid);
			i = pst.executeUpdate();
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return i;
	}

	public Employee retriveEmployeeById(int eid) {
		Employee e = new Employee();
		try {
			String sql = "select * from employee where eid=?";
			PreparedStatement pst = con.prepareStatement(sql);
			pst.setInt(1, eid);
			ResultSet rs = pst.executeQuery();
			if (rs.next()) {
				e.setEid(rs.getInt("eid"));
				e.setEname(rs.getString("ename"));
				e.setSalary(rs.getDouble("salary"));
				e.setBonus(rs.getInt("bonus"));
				e.setMgrNo(rs.getInt("mgrno"));
				e.setJcode(rs.getString("jcode"));
				e.setDeptNo(rs.getInt("deptno"));
				java.sql.Date sqlDate = rs.getDate("doj");
				LocalDate ld = sqlDate.toLocalDate();
				e.setDoj(ld);

			}
		} catch (SQLException e1) {
			e1.printStackTrace();
		}
		return e;
	}

	public List<Employee> retriveEmployeeByJName(String jname) {
		List<Employee> list = new ArrayList<Employee>();
		try {
			String sql = "select * from employee where jcode=(select jcode from job where jname = ?)";
			PreparedStatement pst = con.prepareStatement(sql);
			pst.setString(1, jname);
			ResultSet rs = pst.executeQuery();
			if (rs.next()) {
				Employee e = new Employee();
				e.setEid(rs.getInt("eid"));
				e.setEname(rs.getString("ename"));
				e.setSalary(rs.getDouble("salary"));
				e.setBonus(rs.getInt("bonus"));
				e.setMgrNo(rs.getInt("mgrno"));
				e.setJcode(rs.getString("jcode"));
				e.setDeptNo(rs.getInt("deptno"));
				java.sql.Date sqlDate = rs.getDate("doj");
				LocalDate ld = sqlDate.toLocalDate();
				e.setDoj(ld);
				list.add(e);

			}
		} catch (SQLException e1) {
			e1.printStackTrace();
		}
		return list;
	}

}
