package com.infrrd.training.pojos;

import java.time.LocalDate;

public class Employee {
	private int eid;
	private String ename;
	private double salary;
	private int bonus;
	private int mgrNo;
	private String jcode;
	private int deptNo;
	private LocalDate doj;

	public Employee() {
		super();
	}

	public Employee(int eid, String ename, double salary, int bonus, int mgrNo, String jcode, int deptNo,
			LocalDate doj) {
		super();
		this.eid = eid;
		this.ename = ename;
		this.salary = salary;
		this.bonus = bonus;
		this.mgrNo = mgrNo;
		this.jcode = jcode;
		this.deptNo = deptNo;
		this.doj = doj;
	}

	public int getEid() {
		return eid;
	}

	public void setEid(int eid) {
		this.eid = eid;
	}

	public String getEname() {
		return ename;
	}

	public void setEname(String ename) {
		this.ename = ename;
	}

	public double getSalary() {
		return salary;
	}

	public void setSalary(double salary) {
		this.salary = salary;
	}

	public int getBonus() {
		return bonus;
	}

	public void setBonus(int bonus) {
		this.bonus = bonus;
	}

	public int getMgrNo() {
		return mgrNo;
	}

	public void setMgrNo(int mgrNo) {
		this.mgrNo = mgrNo;
	}

	public String getJcode() {
		return jcode;
	}

	public void setJcode(String jcode) {
		this.jcode = jcode;
	}

	public int getDeptNo() {
		return deptNo;
	}

	public void setDeptNo(int deptNo) {
		this.deptNo = deptNo;
	}

	public LocalDate getDoj() {
		return doj;
	}

	public void setDoj(LocalDate doj) {
		this.doj = doj;
	}

	@Override
	public String toString() {
		return "Employee [eid=" + eid + ", ename=" + ename + ", salary=" + salary + ", bonus=" + bonus + ", mgrNo="
				+ mgrNo + ", jcode=" + jcode + ", deptNo=" + deptNo + ", doj=" + doj + "]";
	}

}
