package com.infrrd.training.services;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

import com.infrrd.training.exceptions.BusinessException;
import com.infrrd.training.exceptions.RecordNotFoundException;
import com.infrrd.training.pojos.*;
import com.infrrd.training.daos.*;
import com.infrrd.training.daosimpl.*;

public class EmployeeServiceImpl implements EmployeeService {

	LocationDao locationDao;
	DepartmentDao departmentDao;
	JobDao jobDao;
	EmployeeDao employeeDao;

	public EmployeeServiceImpl() {
		locationDao = new LocationDaoImpl();
		departmentDao = new DepartmentDaoImpl();
		jobDao = new JobDaoImpl();
		employeeDao = new EmployeeDaoImpl();
	}

	public List<Employee> getAll() throws BusinessException {
		List<Employee> employees = employeeDao.retriveAll();
		if (employees.isEmpty())
			throw new BusinessException("Employee list is empty");
		return employees;
	}

	public int addEmployee(Employee e) throws BusinessException {
		int i = 0;
		if (e.getEid() > 11) {
			if (e.getEname().matches("[A-Z]{3,20}")) {
				if (e.getSalary() > 1000 && e.getSalary() < 100000) {
					if (e.getBonus() < 1000) {
						i = employeeDao.insertEmployee(e);
					} else {
						throw new BusinessException("Bonus should be less than 1000");
					}
				} else {
					throw new BusinessException("Salary range is 1000 to 100000");
				}
			} else {
				throw new BusinessException("Name accepts only uppercase letters");
			}
		} else {
			throw new BusinessException("Invalid Employee id");
		}
		return i;
	}

	public int editEmployeeSalary(double salary, int eId) throws BusinessException {
		int i = 0;
		if (salary > 1000 && salary < 100000) {
			i = employeeDao.updateEmployeeSalary(salary, eId);
		} else {
			throw new BusinessException("Salary range between 1000 and 100000");
		}
		return i;
	}

	public int editEmployeeJob(String jCode, int eId) throws BusinessException {
		int i = 0;
		if (jCode.length() <= 6) {
			i = employeeDao.updateEmployeeJob(jCode, eId);
		} else {
			throw new BusinessException("Job Code should not exceed 6 letters");
		}
		return i;
	}

	public int editEmployeeDepartment(int dCode, int eId) throws BusinessException {
		int i = 0;
		if (dCode > 9 && dCode < 100) {
			i = employeeDao.updateEmployeeDepartment(dCode, eId);
		} else {
			throw new BusinessException("Department number should bo of 3 digits");
		}
		return i;
	}

	public int removeEmployee(int eId) throws RecordNotFoundException {
		return employeeDao.deleteEmployee(eId);
	}

	public Employee getEmployeeById(int eId) throws RecordNotFoundException {
		Employee e = new Employee();
		if (eId > 0 && eId < 100) {
			e =  employeeDao.retriveEmployeeById(eId);
		} else
			throw new RecordNotFoundException("Employee not in database");
		return e;
	}

	public List<Employee> getEmployeeByJName(String jName) throws BusinessException {
		if (jName.length() < 20) {
			return employeeDao.retriveEmployeeByJName(jName);
		} else
			throw new BusinessException("Employee not in database");
	}

	public List<String> getEmployeeNames() throws BusinessException {
		List<Employee> employees = employeeDao.retriveAll();
		List<String> name = new ArrayList<String>();
		if (employees.size() > 0) {
			for (Employee e : employees)
				name.add(e.getEname());
		} else {
			throw new BusinessException("Employee names are not found");
		}
		return name;
	}

	public List<Employee> getSortedEmployeeBasedOnSalary() throws BusinessException {
		List<Employee> employees = employeeDao.retriveAll();
		if (employees.size() > 0) {
			return employees.stream().sorted((e1, e2) -> (int) (e1.getSalary() - e2.getSalary()))
					.collect(Collectors.toList());
		} else {
			throw new BusinessException("No employees in database");
		}
	}

	public List<Employee> getSortedEmployeeBasedOnDoj() throws BusinessException {
		List<Employee> employees = employeeDao.retriveAll();
		if (employees.size() > 0) {
			return employees.stream().sorted((e1, e2) -> e1.getDoj().getYear() - e2.getDoj().getYear())
					.collect(Collectors.toList());
		} else {
			throw new BusinessException("No employees in database");
		}
	}

	public List<Department> getAllDepartment() throws BusinessException {
		List<Department> deps = departmentDao.retriveAll();
		if (deps.isEmpty()) {
			throw new BusinessException("NO departments");
		}
		return deps;
	}

	public int addDepartment(Department d) throws BusinessException {
		int i = 0;
		if (d.getDeptNo() > 9 && d.getDeptNo() < 100) {
			if (d.getDname().length() <= 20) {
				if (d.getLcode() > 99 && d.getLcode() < 1000) {
					i = departmentDao.insertDepartment(d);
				} else {
					throw new BusinessException("Location code should have 3 digits");
				}
			} else {
				throw new BusinessException("Department name should be less than 20");
			}
		} else {
			throw new BusinessException("Department number should have 2 digits");
		}
		return i;
	}

	public int editDepartmentLocation(int lCode, int deptNo) throws BusinessException {
		int i = 0;
		if (deptNo>9&&deptNo<100) {
			if (lCode>99&&lCode<1000) {
				i = departmentDao.updateDepartmentLocation(lCode, deptNo);
			} else {
				throw new BusinessException("Lcode should have 3 digits");
			}
		} else {
			throw new BusinessException("deptNo should have 2 digits");
		}
		return i;
	}

	public int removeDepartment(int deptNo) throws BusinessException {
		return departmentDao.deleteDepartment(deptNo);
	}

	public Department getDepartmentById(int deptNo) throws BusinessException {
		if (deptNo>9&&deptNo<100) {
			return departmentDao.retriveDepartmentById(deptNo);
		} else
			throw new BusinessException("Department not in database");
	}

	public List<Location> getAllLocation() throws BusinessException {
		List<Location> locations = locationDao.retriveAll();
		if (locations.isEmpty())
			throw new BusinessException("No Locations Avaiable");
		return locations;
	}

	public int addLocation(Location l) throws BusinessException {
		int i = 0;
		if (l.getLcode() > 99 && l.getLcode() < 1000) {
			if (l.getLname().length() <= 20) {
				i = locationDao.insertLocation(l);
			} else {
				throw new BusinessException("Job name should not exceed 20 letters");
			}
		} else {
			throw new BusinessException("Location code should have 3 digits");
		}
		return i;
	}

	public int editLocation(int lCode, String lName) throws BusinessException {
		int i = 0;
		if (lCode>99&&lCode<1000) {
			if (lName.length() <= 20) {
				i = locationDao.updateLocation(lCode, lName);
			} else {
				throw new BusinessException("Location name should not exceed 20 letters");
			}
		} else {
			throw new BusinessException("Location code should be of 3 digits");
		}
		return i;
	}

	public int removeLocation(int lCode) throws BusinessException {
		return locationDao.deleteLocation(lCode);
	}

	public Location getLocationById(int lCode) throws BusinessException {
		if (lCode>99&&lCode<1000) {
			return locationDao.retriveLocationById(lCode);
		} else
			throw new BusinessException("Location not in database");
	}

	public List<Job> getAllJob() throws BusinessException {
		List<Job> jobs = jobDao.retriveAll();
		if (jobs.isEmpty())
			throw new BusinessException("No Jobs Avaiable");
		return jobs;
	}

	public int addJob(Job j) throws BusinessException {
		int i = 0;
		if (j.getJcode().length() <= 6) {
			if (j.getJname().length() <= 20) {
				i = jobDao.insertJob(j);
			} else {
				throw new BusinessException("Job name should not exceed 20 letters");
			}
		} else {
			throw new BusinessException("Job code should not exceed 6 letters");
		}
		return i;
	}

	public int editJob(String jCode, String jName) throws BusinessException {
		int i = 0;
		if (jCode.length() <= 6) {
			if (jName.length() <= 20) {
				i = jobDao.updateJob(jCode, jName);
			} else {
				throw new BusinessException("Job name should not exceed 20 letters");
			}
		} else {
			throw new BusinessException("Job code should not exceed 6 letters");
		}
		return i;
	}

	public int removeJob(String jCode) throws BusinessException {
		return jobDao.deleteJob(jCode);
	}

	public Job getJobById(String jCode) throws BusinessException {
		if (jCode.length() <= 6) {
			return jobDao.retriveJobById(jCode);
		} else
			throw new BusinessException("Job not in database");
	}

}
