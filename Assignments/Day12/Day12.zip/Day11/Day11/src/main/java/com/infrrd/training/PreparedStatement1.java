package com.infrrd.training;

import java.sql.*;
import java.util.Scanner;

public class PreparedStatement1 {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		try {
			Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/infrrd", "root", "Kavil@514");
			System.out.println("Connected");
			String sql = "insert into job values(?,?)";
			PreparedStatement pst = conn.prepareStatement(sql);
			System.out.println("Enter Job code");
			pst.setString(1,sc.next());
			System.out.println("Enter Job name");
			pst.setString(2,sc.next());
			int i = pst.executeUpdate();
			if(i>0) {
				System.out.println("Inserted");
			}
			else {
				System.out.println("Not Inserted");
			}
			Statement st = conn.createStatement();
			ResultSet rs = st.executeQuery("select * from job");
			while (rs.next()) {
				System.out.println(rs.getString(1) + " " + rs.getString(2));
			}
			}
		catch(SQLException e) {
			e.printStackTrace();
		}
		sc.close();
	}

}
