package com.infrrd.training.daosimpl;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import com.infrrd.training.daos.DepartmentDao;
import com.infrrd.training.pojos.Department;
import com.infrrd.training.util.DbUtil;

public class DepartmentDaoImpl implements DepartmentDao {

	private Connection con = null;

	public DepartmentDaoImpl() {
		con = DbUtil.openConnection();
	}

	public List<Department> retriveAll() {
		List<Department> department = new ArrayList<Department>();
		try {
			Statement st = con.createStatement();
			ResultSet rs = st.executeQuery("select * from department;");
			while (rs.next()) {
				Department d = new Department();
				d.setDeptNo(rs.getInt("deptno"));
				d.setDname(rs.getString("Dname"));
				d.setLcode(rs.getInt("lcode"));
				department.add(d);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return department;
	}

	public int insertDepartment(Department d) {
		int i = 0;
		try {
			String sql = "insert into department values(?,?,?)";
			PreparedStatement pst = con.prepareStatement(sql);
			pst.setInt(1, d.getDeptNo());
			pst.setString(2, d.getDname());
			pst.setInt(3, d.getLcode());
			i = pst.executeUpdate();
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return i;
	}

	public int updateDepartmentLocation(int lCode, int deptNo) {
		int i = 0;
		try {
			String sql = "update department set lcode=? where deptno=? ";
			PreparedStatement pst = con.prepareStatement(sql);
			pst.setInt(1, lCode);
			pst.setInt(2, deptNo);
			i = pst.executeUpdate();
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return i;
	}

	public int deleteDepartment(int deptNo) {
		int i = 0;
		try {
			String sql = "delete from department where deptno=?";
			PreparedStatement pst = con.prepareStatement(sql);
			pst.setInt(1, deptNo);
			i = pst.executeUpdate();
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return i;
	}

	public Department retriveDepartmentById(int deptNo) {
		Department d = new Department();
		try {
			String sql = "select * from department where deptno = ?;";
			PreparedStatement pst = con.prepareStatement(sql);
			pst.setInt(1, deptNo);
			ResultSet rs = pst.executeQuery();
			while (rs.next()) {
				d.setDeptNo(rs.getInt("deptno"));
				d.setDname(rs.getString("dname"));
				d.setLcode(rs.getInt("lcode"));
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return d;
	}

}
