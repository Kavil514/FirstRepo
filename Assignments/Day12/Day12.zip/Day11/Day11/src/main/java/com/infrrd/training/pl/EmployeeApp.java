package com.infrrd.training.pl;

import java.time.LocalDate;
import java.util.List;
import java.util.Scanner;

import com.infrrd.training.exceptions.BusinessException;
import com.infrrd.training.exceptions.RecordNotFoundException;
import com.infrrd.training.pojos.*;
import com.infrrd.training.services.EmployeeService;
import com.infrrd.training.services.EmployeeServiceImpl;
import com.infrrd.training.util.DbUtil;

public class EmployeeApp {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.println("Welcome To Employee  Portal");
		EmployeeService employeeService = new EmployeeServiceImpl();
		do {
			System.out.println("1. View Employees\n2. View Jobs\n3. View Locations\n4. View Departments"
					+ "\n5. Add Employee\n6. Update Salary\n7. Update Job\n8. Update Department\n9. Get Employee by ID\n10. Get Employee by JName\n11. Get Names of all employees.\n12. Remove Employee"
					+ "\n13. Add Job\n14. Update Job\n15. Get Job By JobID"
					+ "\n16. Add Location\n17. Update Location\n18. Get Locaion by Id"
					+ "\n19. Add Department\n20. Update Department Location\n21. Get Department by Id"
					+ "\n22. Delete Job\n23. Delete Department\n24. Delete Location"
					+ "\n25. Sorted Employees based on salary\n26. Sorted Employees based on DoJ\n27. Exit");
			switch (sc.nextInt()) {
			case 1:
				try {
					List<Employee> employees = employeeService.getAll();
					employees.forEach(System.out::println);
				} catch (BusinessException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				break;
			case 2:
				try {
					List<Job> jobs = employeeService.getAllJob();
					jobs.forEach(System.out::println);
				} catch (BusinessException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				break;
			case 4:
				try {
					List<Department> departments = employeeService.getAllDepartment();
					departments.forEach(System.out::println);
				} catch (BusinessException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				break;
			case 3:
				try {
					List<Location> locations = employeeService.getAllLocation();
					locations.forEach(System.out::println);
				} catch (BusinessException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				break;
			case 5:
				System.out.println("Enter Employee Details");
				try {
					Employee e = new Employee();
					System.out.println("Enter eid");
					e.setEid(sc.nextInt());
					System.out.println("Enter ename(Uppercase letters)");
					e.setEname(sc.next());
					System.out.println("Enter Salary Range(1000 to 100000)");
					e.setSalary(sc.nextDouble());
					System.out.println("Enter Bonus (< 1000)");
					e.setBonus(sc.nextInt());
					System.out.println("Enter ManagerNo");
					e.setMgrNo(sc.nextInt());
					System.out.println("Enter Jcode");
					List<Job> jobs = employeeService.getAllJob();
					jobs.forEach(System.out::println);
					e.setJcode(sc.next());
					System.out.println("Enter Deptno");
					System.out.println("Select the existing deptno");
					List<Department> deps = employeeService.getAllDepartment();
					deps.forEach(System.out::println);
					e.setDeptNo(sc.nextInt());
					System.out.println("Enter Date of Birth (yyyy mm dd)");
					e.setDoj(LocalDate.of(sc.nextInt(), sc.nextInt(), sc.nextInt()));
					int i = employeeService.addEmployee(e);
					if (i > 0) {
						System.out.println("Employee inserted");
					}
				} catch (BusinessException e1) {
					System.out.println(e1.getMessage());
				}
				break;
			case 6:
				System.out.println("Enter employee id");
				int eid = sc.nextInt();
				System.out.println("Enter new salary");
				double salary = sc.nextDouble();
				try {
					employeeService.editEmployeeSalary(salary, eid);
				} catch (BusinessException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				System.out.println("SALARY UPDATED!!");
				break;
			case 7:
				try {
					System.out.println("Enter employee id");
					int eId = sc.nextInt();
					List<Job> jobs = employeeService.getAllJob();
					jobs.forEach(System.out::println);
					System.out.println("Enter new Job code");
					String jobCode = sc.next();
					employeeService.editEmployeeJob(jobCode, eId);
				} catch (BusinessException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				System.out.println("JOB UPDATED!!");
				break;
			case 8:
				try {
					System.out.println("Enter employee id");
					int eid1 = sc.nextInt();
					List<Department> deps = employeeService.getAllDepartment();
					deps.forEach(System.out::println);
					System.out.println("Enter department number");
					int deptNum = sc.nextInt();
					employeeService.editEmployeeDepartment(deptNum, eid1);
				} catch (BusinessException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				System.out.println("DEPARTMENT UPDATED!!");
				break;
			case 9:
				System.out.println("Enter Employee ID");
				int eid2 = sc.nextInt();
				try {
					System.out.println(employeeService.getEmployeeById(eid2));
				} catch (RecordNotFoundException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
				break;
			case 10:
				try {
					System.out.print("Enter Job Name");
					List<Job> jobs2 = employeeService.getAllJob();
					jobs2.forEach(System.out::println);
					String jName = sc.next();
					System.out.println(employeeService.getEmployeeByJName(jName));
				} catch (BusinessException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
				break;
			case 11:
				System.out.println("All Employee names are:");
				try {
					System.out.println(employeeService.getEmployeeNames());
				} catch (BusinessException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
				break;
			case 12:
				System.out.println("Enter the employee id");
				try {
					employeeService.removeEmployee(sc.nextInt());
				} catch (RecordNotFoundException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				System.out.println("EMPLOYEE REMOVED");
				break;
			case 13:
				System.out.println("Enter New Job Details");
				try {
					Job j = new Job();
					System.out.println("Enter Job code");
					j.setJcode(sc.next());
					System.out.println("Enter Job name");
					j.setJname(sc.next());
					int i = employeeService.addJob(j);
					if (i > 0) {
						System.out.println("JOB ADDED");
					}
				} catch (BusinessException e) {
					e.printStackTrace();
				}
				break;
			case 14:
				try {
					System.out.println("Enter Job code for updating Job name");
					List<Job> jobs1 = employeeService.getAllJob();
					jobs1.forEach(System.out::println);
					String jCode = sc.next();
					System.out.println("Enter new Job name");
					String jobName1 = sc.next();
					employeeService.editJob(jCode, jobName1);
				} catch (BusinessException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				System.out.println("JOB DETAILS UPDATED!!");
				break;
			case 15:
				try {
					System.out.println("Enter Job code");
					List<Job> jobs1 = employeeService.getAllJob();
					jobs1.forEach(e -> System.out.println(e.getJcode()));
					String jCode1 = sc.next();
					System.out.println(employeeService.getJobById(jCode1));
				} catch (BusinessException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				break;
			case 16:
				System.out.println("Enter New Location Details");
				try {
					List<Location> locations = employeeService.getAllLocation();
					locations.forEach(System.out::println);
					Location l = new Location();
					System.out.println("Enter Location code");
					l.setLcode(sc.nextInt());
					System.out.println("Enter Location name");
					l.setLname(sc.next());
					int i = employeeService.addLocation(l);
					if (i > 0) {
						System.out.println("LOCATION ADDED");
					}
				} catch (BusinessException e) {
					e.printStackTrace();
				}
				break;
			case 17:
				try {
					List<Location> locations1 = employeeService.getAllLocation();
					locations1.forEach(System.out::println);
					System.out.println("Enter Location code");
					int lCode = sc.nextInt();
					System.out.println("Enter new Location name");
					String lName = sc.next();
					employeeService.editLocation(lCode, lName);
				} catch (BusinessException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				System.out.println("LOCATION DETAILS UPDATED!!");
				break;
			case 18:
				try {
					List<Location> locations1 = employeeService.getAllLocation();
					locations1.forEach(e -> System.out.println(e.getLcode()));
					System.out.println("Enter Location code");
					int lCode1 = sc.nextInt();
					System.out.println(employeeService.getLocationById(lCode1));
				} catch (BusinessException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				break;
			case 19:
				System.out.println("Enter New Department Details");
				try {
					List<Department> deps1 = employeeService.getAllDepartment();
					deps1.forEach(System.out::println);
					Department d = new Department();
					System.out.println("Enter Department code");
					d.setDeptNo(sc.nextInt());
					System.out.println("Enter Department name");
					d.setDname(sc.next());
					System.out.println("Enter Location code for the department");
					List<Location> locations1 = employeeService.getAllLocation();
					locations1.forEach(System.out::println);
					d.setLcode(sc.nextInt());
					int i = employeeService.addDepartment(d);
					if (i > 0) {
						System.out.println("DEPARTMENT ADDED");
					}
				} catch (BusinessException e) {
					e.printStackTrace();
				}
				break;
			case 20:
				try {
					List<Department> deps1 = employeeService.getAllDepartment();
					deps1.forEach(System.out::println);
					System.out.println("Enter Department number");
					int deptNo = sc.nextInt();
					System.out.println("Enter Location code");
					int lCode3 = sc.nextInt();
					employeeService.editDepartmentLocation(lCode3, deptNo);
				} catch (BusinessException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				System.out.println("DEPARTMENT LOCATION UPDATED!!");
				break;
			case 21:
				try {
					List<Department> deps1 = employeeService.getAllDepartment();
					deps1.forEach(e -> System.out.println(e.getDeptNo()));
					System.out.println("Enter Department number");
					int deptNo1 = sc.nextInt();
					System.out.println(employeeService.getDepartmentById(deptNo1));
				} catch (BusinessException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				break;
			case 22:
				try {
					List<Job> jobs1 = employeeService.getAllJob();
					jobs1.forEach(e -> System.out.println(e.getJcode()));
					System.out.println("Enter the Job code");
					employeeService.removeJob(sc.next());
				} catch (BusinessException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				System.out.println("JOB REMOVED");
				break;
			case 23:
				try {
					List<Department> deps1 = employeeService.getAllDepartment();
					deps1.forEach(e -> System.out.println(e.getDeptNo()));
					System.out.println("Enter the Department number");
					employeeService.removeDepartment(sc.nextInt());
				} catch (BusinessException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				System.out.println("DEPARTMENT REMOVED");
				break;
			case 24:
				try {
					List<Location> locations1 = employeeService.getAllLocation();
					locations1.forEach(e -> System.out.println(e.getLcode()));
					System.out.println("Enter the Location code");

					employeeService.removeLocation(sc.nextInt());
				} catch (BusinessException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				System.out.println("EMPLOYEE REMOVED");
				break;
			case 25:
				System.out.println("Sorted List in ascending order of Salary");
				try {
					System.out.println(employeeService.getSortedEmployeeBasedOnSalary());
				} catch (BusinessException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				break;
			case 26:
				System.out.println("Sorted List in asceding order of DOJ");
				try {
					System.out.println(employeeService.getSortedEmployeeBasedOnDoj());
				} catch (BusinessException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				break;
			case 27:
				System.out.println("Thank You");
				DbUtil.closeConnection();
				sc.close();
				System.exit(0);
				break;
			default:
				System.out.println("Invalid");
			}
		} while (true);
	}

}
