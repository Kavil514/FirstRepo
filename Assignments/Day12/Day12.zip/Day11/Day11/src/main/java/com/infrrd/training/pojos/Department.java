package com.infrrd.training.pojos;

public class Department {
	private int deptNo;
	private String dname;
	private int lcode;

	public Department() {
		super();
	}

	public Department(int deptNo, String dname, int lcode) {
		super();
		this.deptNo = deptNo;
		this.dname = dname;
		this.lcode = lcode;
	}

	public int getDeptNo() {
		return deptNo;
	}

	public void setDeptNo(int deptNo) {
		this.deptNo = deptNo;
	}

	public String getDname() {
		return dname;
	}

	public void setDname(String dname) {
		this.dname = dname;
	}

	public int getLcode() {
		return lcode;
	}

	public void setLcode(int lcode) {
		this.lcode = lcode;
	}

	@Override
	public String toString() {
		return "Department [deptNo=" + deptNo + ", dname=" + dname + ", lcode=" + lcode + "]";
	}

}
